# BeamP2P

Peer-to-peer multiplayer for BeamNG.drive. No server to host or pay for: you type a room name and password, your friends type the same, and you find each other directly. Works on Linux (native build or Proton) and Windows.

## Playing

1. Install [Node.js](https://nodejs.org) 18 or newer (once).
2. Run `start.sh` (Linux) or double-click `start.bat` (Windows).
   - The first run installs dependencies and copies the mod into your BeamNG `mods/unpacked/beamp2p` folder.
3. A launcher page opens in your browser. Enter your name, a room name and a password, then click **Join room**. Leave the terminal open; closing it quits the launcher.
   - Prefer the terminal? Run with `--cli`, or pass `--room` and `--password`.
4. Start BeamNG.drive, make sure the **beamp2p** mod is enabled, and load a map. Everyone should load the same map.
5. Spawn a car. Friends' cars appear as they spawn theirs.

Chat from the launcher page; messages show in-game. **Reset others' cars** repairs every other player's car and puts it back where its owner really is (also bindable in-game under Options → Controls → BeamP2P).

Options: `--cli`, `--no-browser`, `--ui-port 4460`, `--name`, `--room`, `--password`, `--max-players 8`, `--port 4455`, `--mods "<path to mods folder>"` (if auto-detect misses your install), `--no-install`, `--install-only`.

## How it works

- **No central server.** Peers meet on the public Hyperswarm DHT, a distributed network with no owner. It uses UDP hole punching to connect players directly, so no port forwarding is needed in most cases.
- **The launcher** bridges the game, over localhost port 4455, and the peers. Every player connects to every other player, and nobody is the host.
- **The mod** sends your cars' position, rotation, velocity, controls and lights 20 times a second. Remote cars replay those controls and are gently pulled toward the owner's position. They only jump if they end up over 100 m off.
- **Damage sync:** twice a second your car reports newly broken beams (parts falling off, glass) and bent beams (deformation). Copies apply the same damage. It only applies between identical cars (same model and config); otherwise it's skipped and logged.
- **The launcher page** is served only on 127.0.0.1 and needs a random token in its link, so other websites can't control it. Name and recent rooms are saved in `~/.config/beamp2p/config.json` (Windows: `%APPDATA%\beamp2p`); passwords never are.

## Security

- The room is located by a key derived from **room name + password** with scrypt. Without the password you can't even find the room, and the slow key derivation makes guessing expensive.
- All traffic is end-to-end encrypted (Noise protocol, built into Hyperswarm).
- Each new peer must prove it knows the password with an HMAC challenge, tied to that specific encrypted connection, before anything is accepted. Failing peers are dropped after 10 seconds.
- Incoming messages are allow-listed and type-checked. Peers can only send car spawns, car states, damage, resets, map name and chat; they can never send Lua code. Messages are size-capped, and peers that flood are disconnected.
- Use a long, unique password (10+ characters). Anyone who has the password can join.
- Your IP address is visible to the other players in the room, as with any direct P2P game.

## Limitations (v0.2)

- Damage sync is new. Each screen also adds its own local crash damage on top, so dents can differ slightly. Check `beamng.log` for `damage sync:` to see which parts are active on your game version.
- Everyone needs the same vehicle mods and the same map. A warning shows if maps differ.
- Very strict NATs, such as some mobile hotspots and CGNAT on both sides, may fail to connect, because there's no relay.
- Some BeamNG Lua APIs this relies on can change between game updates. Check `beamng.log` for lines tagged `beamp2p` if something stops working.
