@echo off
rem BeamP2P launcher for Windows
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or newer is required. Download the LTS installer from https://nodejs.org
  pause
  exit /b 1
)
if not exist node_modules (
  echo First run: installing dependencies...
  call npm install --omit=dev
  if errorlevel 1 ( pause & exit /b 1 )
)
node launcher.js %*
pause
