-- BeamP2P: vehicle side (runs inside each car's own Lua VM).
-- Your cars: report inputs/electrics and damage (broken + bent beams) to the game engine.
-- Remote cars (copies of other players' cars) are STATE-driven: every frame they are
-- pushed toward the owner's real position, speed, facing and spin (predicted ahead by
-- the network lag). The owner's pedals/steering are replayed only so wheels, steering
-- and lights look right. If a copy still ends up too far off, the game engine moves it
-- straight to the right spot (without repairing it).
local M = {}

local isRemote = false
local isOwned = false
local reportTimer = 0
local clock = 0
local warned = {}

local REPORT_INTERVAL = 1 / 30  -- how often your car reports inputs (s)

-- position / speed pull
local POS_CORRECT = 5.0     -- speed used to close a position gap (m/s per m)
local POS_GAIN = 5.0        -- how quickly the speed difference is removed (1/s)
local MAX_ACC = 60.0        -- cap on the push (m/s^2)
-- rotation pull
local ROT_CORRECT = 6.0     -- turn rate used to close a facing gap (rad/s per unit of error)
local ROT_GAIN = 7.0        -- how quickly the spin difference is removed (1/s)
local MAX_ROT_ACCEL = 40.0  -- cap on the twist (rad/s^2)
-- prediction / teleport
local MAX_PREDICT = 0.3     -- never predict further ahead than this (s)
local TP_INSTANT = 6.0      -- jump straight away if this far off (m) ...
local TP_INSTANT_PER_MS = 0.5   -- ... plus this much per m/s of speed
local TP_SLOW = 2.5         -- jump if this far off (m) ...
local TP_SLOW_PER_MS = 0.3  -- ... plus this per m/s ...
local TP_SLOW_TIME = 1.5    -- ... for this long (s)
local TP_FLIPPED_TIME = 1.5 -- jump if facing more than 90 degrees wrong for this long (s)

local DAMAGE_INTERVAL = 0.5   -- seconds between damage scans on your own car
local DEFORM_THRESHOLD = 0.02  -- a beam counts as bent once its rest length changes by 2%
local DAMAGE_CHUNK = 400      -- items per message

local function warnOnce(key, err)
  if warned[key] then return end
  warned[key] = true
  log('E', 'beamp2pVeh', key .. ': ' .. tostring(err))
end

local function refNode()
  local rn = v and v.data and v.data.refNodes and v.data.refNodes[0]
  return rn and rn.ref or 0
end

local function setRemote(on)
  isRemote = on and true or false
  if isRemote and ai and ai.setMode then pcall(ai.setMode, 'disabled') end
  if isRemote then
    -- record this copy's undamaged beam lengths now, for the damage comparison
    local ok, err = pcall(function() M._detect() end)
    if not ok then warnOnce('detect', err) end
  end
end

local function setOwned(on) isOwned = on and true or false end

-- ---------- sync diagnostics (copy side) ----------
-- Every SAMPLE_INTERVAL the copy compares itself with the owner's real (lag-corrected)
-- state and sends a sample to the launcher, which logs it and shows it to both players.
local SAMPLE_INTERVAL = 0.5
local sampleTimer = SAMPLE_INTERVAL
local st = nil                        -- running sums for the current sample
local tpTotal, tpLastReason = 0, 0    -- teleports since spawn; 1 instant, 2 far, 3 flipped
local pktCount = 0                    -- owner updates received this sample
local ownerIn = { thr = 0, steer = 0, ws = 0, rpm = 0 }
local ownerDmg = nil                  -- owner's { broken, bent } totals
local function resetStats()
  st = { n = 0, pe = 0, pm = 0, ve = 0, ae = 0, am = 0, ue = 0, se = 0, sp = 0, cs = 0,
         ag = 0, pu = 0, tw = 0, capped = 0 }
end
resetStats()
local function deg(x) return math.deg(math.acos(math.max(-1, math.min(1, x)))) end


-- ---------- vector helpers ----------
local function cross3(a, b)
  return { a[2] * b[3] - a[3] * b[2], a[3] * b[1] - a[1] * b[3], a[1] * b[2] - a[2] * b[1] }
end
local function dot3(a, b) return a[1] * b[1] + a[2] * b[2] + a[3] * b[3] end
local function len3(a) return math.sqrt(dot3(a, a)) end
local function norm3(a)
  local l = len3(a)
  if l < 1e-9 then return a end
  return { a[1] / l, a[2] / l, a[3] / l }
end
local function capLen(a, cap)
  local l = len3(a)
  if l > cap and l > 0 then local s = cap / l; return { a[1] * s, a[2] * s, a[3] * s } end
  return a
end

-- ---------- replaying the owner's controls (looks only) ----------
local function inputEvent(name, value)
  if input and input.event then
    local ok, err = pcall(input.event, name, value, 2)
    if not ok then warnOnce('input.' .. name, err) end
  end
end

local function applyInputs(thr, brk, steer, pb, lights, horn, sigL, sigR, ws, rpm)
  if not isRemote then return end
  ownerIn = { thr = thr or 0, steer = steer or 0, ws = ws or 0, rpm = rpm or 0 }
  inputEvent('throttle', thr)
  inputEvent('brake', brk)
  inputEvent('steering', steer)
  inputEvent('parkingbrake', pb)
  if electrics and electrics.values then
    if electrics.setLightsState then pcall(electrics.setLightsState, lights) end
    if electrics.horn then pcall(electrics.horn, horn > 0.5) end
    if electrics.toggle_left_signal then
      local ev = electrics.values
      if (sigL > 0.5) ~= ((ev.signal_left_input or 0) > 0.5) then pcall(electrics.toggle_left_signal) end
      if (sigR > 0.5) ~= ((ev.signal_right_input or 0) > 0.5) then pcall(electrics.toggle_right_signal) end
    end
  end
end

-- ---------- state sync ----------
local tgt = nil             -- owner's latest { p, v, d, u, w, t = time received, lat = one-way lag }
local prevMy = nil          -- copy's forward/up last frame, for measuring its spin
local mySpin = { 0, 0, 0 }  -- smoothed measured spin of the copy
local cogRel = nil          -- centre of mass relative to the ref node (world-oriented)
local cogTimer = 0
local physicsFPS = nil
local farSince, flippedSince = nil, nil
local tpCooldown = 0

local function updateCog()
  local sx, sy, sz, sm = 0, 0, 0, 0
  for _, n in pairs((v and v.data and v.data.nodes) or {}) do
    if type(n) == 'table' and n.cid then
      local m = obj:getNodeMass(n.cid)
      local p = obj:getNodePosition(n.cid)
      sx, sy, sz, sm = sx + p.x * m, sy + p.y * m, sz + p.z * m, sm + m
    end
  end
  if sm > 0 then cogRel = { sx / sm, sy / sm, sz / sm } end
end

-- latest owner state (called by the game engine ~30 times a second)
local MAX_EST_ACC = 30.0   -- ignore acceleration estimates above this (m/s^2): crashes, resets

local function applyState(px, py, pz, vx, vy, vz, dx, dy, dz, ux, uy, uz, wx, wy, wz, lat)
  if not isRemote then return end
  -- owner's acceleration, from how their speed changed since the last update (smoothed).
  -- Lets the copy follow curves and braking without trailing behind.
  local acc = { 0, 0, 0 }
  if tgt then
    local gap = clock - tgt.t
    if gap > 0.005 and gap < 0.5 then
      local raw = { (vx - tgt.v[1]) / gap, (vy - tgt.v[2]) / gap, (vz - tgt.v[3]) / gap }
      if len3(raw) < MAX_EST_ACC then
        for n = 1, 3 do acc[n] = tgt.a[n] + (raw[n] - tgt.a[n]) * 0.4 end
      end
    end
  end
  pktCount = pktCount + 1
  tgt = { p = { px, py, pz }, v = { vx, vy, vz }, a = acc, d = { dx, dy, dz }, u = { ux, uy, uz },
          w = { wx, wy, wz }, t = clock, lat = math.max(0, math.min(lat or 0, MAX_PREDICT)) }
end

local function requestTeleport(tp, tv, tD, tU, reason)
  tpTotal = tpTotal + 1
  tpLastReason = reason or 0
  tpCooldown = 1.0
  farSince, flippedSince = nil, nil
  prevMy, mySpin = nil, { 0, 0, 0 }
  obj:queueGameEngineLua(string.format('beamp2p.teleportCopy(%d,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f)',
    obj:getID(), tp[1], tp[2], tp[3], tv[1], tv[2], tv[3], tD[1], tD[2], tD[3], tU[1], tU[2], tU[3]))
end

local function sync(dt)
  if dt <= 0 then return end
  tpCooldown = math.max(0, tpCooldown - dt)
  local myD = { obj:getDirectionVectorXYZ() }
  local myU = { obj:getDirectionVectorUpXYZ() }

  -- how fast the copy is turning right now
  if prevMy then
    local a, b = cross3(prevMy.d, myD), cross3(prevMy.u, myU)
    local k = math.min(30 * dt, 1)
    for n = 1, 3 do mySpin[n] = mySpin[n] + ((a[n] + b[n]) / dt - mySpin[n]) * k end
  end
  prevMy = { d = myD, u = myU }

  if not tgt then return end
  local age = clock - tgt.t
  if age > 1.0 then return end   -- no fresh data (owner paused / lagging): leave it alone

  cogTimer = cogTimer - dt
  if not cogRel or cogTimer <= 0 then cogTimer = 0.5; updateCog() end

  -- predict where the owner's car is now: packet age + network lag
  local pt = math.min(age + tgt.lat, MAX_PREDICT)
  local a = tgt.a
  local tv = { tgt.v[1] + a[1] * pt, tgt.v[2] + a[2] * pt, tgt.v[3] + a[3] * pt }
  local h = 0.5 * pt * pt
  local tp = { tgt.p[1] + tgt.v[1] * pt + a[1] * h, tgt.p[2] + tgt.v[2] * pt + a[2] * h,
               tgt.p[3] + tgt.v[3] * pt + a[3] * h }
  local w = tgt.w
  local wd, wu = cross3(w, tgt.d), cross3(w, tgt.u)
  local tD = norm3({ tgt.d[1] + wd[1] * pt, tgt.d[2] + wd[2] * pt, tgt.d[3] + wd[3] * pt })
  local tU = norm3({ tgt.u[1] + wu[1] * pt, tgt.u[2] + wu[2] * pt, tgt.u[3] + wu[3] * pt })

  local myP = { obj:getPositionXYZ() }
  local myV = { obj:getVelocityXYZ() }
  local posErr = { tp[1] - myP[1], tp[2] - myP[2], tp[3] - myP[3] }
  local dist = len3(posErr)
  local speed = len3(tv)
  local fd = dot3(myD, tD)

  -- way off: move it straight there (the game engine does it without repairing the car)
  if tpCooldown <= 0 then
    if dist > TP_SLOW + TP_SLOW_PER_MS * speed then farSince = farSince or clock else farSince = nil end
    if fd < 0 then flippedSince = flippedSince or clock else flippedSince = nil end
    if dist > TP_INSTANT + TP_INSTANT_PER_MS * speed
      or (farSince and clock - farSince > TP_SLOW_TIME)
      or (flippedSince and clock - flippedSince > TP_FLIPPED_TIME) then
      local reason = (dist > TP_INSTANT + TP_INSTANT_PER_MS * speed) and 1
        or ((farSince and clock - farSince > TP_SLOW_TIME) and 2 or 3)
      requestTeleport(tp, tv, tD, tU, reason)
      return
    end
  end

  -- position + speed: push toward the owner's predicted position and speed
  local kp = math.min(POS_GAIN * dt, 1)
  local dv = {}
  for n = 1, 3 do dv[n] = ((tv[n] - myV[n]) + posErr[n] * POS_CORRECT) * kp + a[n] * dt end
  local dvRaw = len3(dv)
  dv = capLen(dv, MAX_ACC * dt)

  -- rotation: twist toward the owner's facing and spin
  local e1, e2 = cross3(myD, tD), cross3(myU, tU)
  local err = { e1[1] + e2[1], e1[2] + e2[2], e1[3] + e2[3] }
  if fd < 0 then
    -- more than 90 degrees off: keep pushing round the up axis
    local s = dot3(err, myU) >= 0 and 1 or -1
    local extra = s * (1 - fd)
    err = { err[1] + myU[1] * extra, err[2] + myU[2] * extra, err[3] + myU[3] * extra }
  end
  local kr = math.min(ROT_GAIN * dt, 1)
  local dw = {}
  for n = 1, 3 do dw[n] = (w[n] + err[n] * ROT_CORRECT - mySpin[n]) * kr end
  local dwRaw = len3(dw)
  dw = capLen(dw, MAX_ROT_ACCEL * dt)

  -- diagnostics: how far this copy is from the owner's real car right now
  local velErr = { tv[1] - myV[1], tv[2] - myV[2], tv[3] - myV[3] }
  local spinErr = { w[1] - mySpin[1], w[2] - mySpin[2], w[3] - mySpin[3] }
  local ang = deg(fd)
  st.n = st.n + 1
  st.pe = st.pe + dist; st.pm = math.max(st.pm, dist)
  st.ve = st.ve + len3(velErr)
  st.ae = st.ae + ang; st.am = math.max(st.am, ang)
  st.ue = st.ue + deg(dot3(myU, tU))
  st.se = st.se + math.deg(len3(spinErr))
  st.sp = st.sp + speed; st.cs = st.cs + len3(myV)
  st.ag = st.ag + age * 1000
  st.pu = st.pu + len3(dv) / dt; st.tw = st.tw + len3(dw) / dt
  if dvRaw > MAX_ACC * dt or dwRaw > MAX_ROT_ACCEL * dt then st.capped = st.capped + 1 end

  if len3(dv) < 1e-5 and len3(dw) < 1e-5 then return end

  -- one push for both: spin about the centre of mass (cancel the sideways kick there)
  local kick = cross3(dw, cogRel or { 0, 0, 0 })
  physicsFPS = physicsFPS or (obj.getPhysicsFPS and obj:getPhysicsFPS()) or 2000
  local f = physicsFPS
  obj:applyClusterLinearAngularAccel(refNode(),
    vec3((dv[1] - kick[1]) * f, (dv[2] - kick[2]) * f, (dv[3] - kick[3]) * f),
    vec3(dw[1] * f, dw[2] * f, dw[3] * f))
  for n = 1, 3 do mySpin[n] = mySpin[n] + dw[n] end
end

-- ---------- your car -> inputs report ----------
local function report()
  local ev = electrics and electrics.values or {}
  local data = {
    i = {
      throttle = ev.throttle_input or ev.throttle or 0,
      brake = ev.brake_input or ev.brake or 0,
      steering = ev.steering_input or 0,
      parkingbrake = ev.parkingbrake_input or ev.parkingbrake or 0,
    },
    e = {
      lights = ev.lights_state or 0,
      horn = ev.horn or 0,
      signal_L = ev.signal_left_input or 0,
      signal_R = ev.signal_right_input or 0,
    },
    x = { ws = ev.wheelspeed or 0, rpm = ev.rpm or 0 },   -- for the other player's sync check
  }
  obj:queueGameEngineLua('beamp2p.onVehInput(' .. obj:getID() .. ',' .. serialize(data) .. ')')
end

-- ---------- damage ----------
-- Both cars must be the same model + config, so beam ids line up. The beam count
-- travels with every damage message and mismatching cars ignore each other's damage.
local feat = nil          -- { breaks = bool, deform = bool }
local beamIds = nil       -- sorted beam ids
local baseLen = {}        -- id -> undamaged rest length
local sentBroken = {}     -- id -> true once reported
local sentLen = {}        -- id -> last reported rest length
local damageTimer = 0
local fullDamageAt = nil  -- clock time to send a full damage snapshot

local function hasMethod(name)
  local ok, f = pcall(function() return obj[name] end)
  return ok and f ~= nil
end

local function detect()
  if feat then return end
  feat = {
    breaks = hasMethod('beamIsBroken') and hasMethod('breakBeam'),
    deform = hasMethod('getBeamRestLength') and hasMethod('setBeamRestLength'),
  }
  -- Only structural beams (type normal/anisotropic). Hydraulics (steering!), pressured,
  -- bounded (suspension), support and L-beams change length during normal driving, so
  -- copying them makes the other player's copy fight itself and fly apart.
  beamIds = {}
  for _, b in pairs((v and v.data and v.data.beams) or {}) do
    if type(b) == 'table' and b.cid and (b.beamType == nil or b.beamType == 0 or b.beamType == 1) then
      beamIds[#beamIds + 1] = b.cid
    end
  end
  table.sort(beamIds)
  if feat.deform then
    for _, cid in ipairs(beamIds) do baseLen[cid] = obj:getBeamRestLength(cid) end
  end
  log('I', 'beamp2pVeh', string.format('damage sync: %d structural beams, breaks=%s, deform=%s',
    #beamIds, tostring(feat.breaks), tostring(feat.deform)))
end

local function sendDamage(b, d, full)
  local n = #beamIds
  local nb, nd = #b, #d
  if nb == 0 and nd == 0 and not full then return end
  local i, j = 1, 1
  repeat
    local cb, cd = {}, {}
    while i <= nb and #cb < DAMAGE_CHUNK do cb[#cb + 1] = b[i]; i = i + 1 end
    while j <= nd and #cd + #cb < DAMAGE_CHUNK do cd[#cd + 1] = d[j]; j = j + 1 end
    obj:queueGameEngineLua(string.format('beamp2p.onVehDamage(%d,%s)', obj:getID(),
      serialize({ n = n, b = cb, d = cd, full = full and true or false })))
    full = false   -- only the first chunk of a snapshot is marked full
  until i > nb and j > nd
end

local function scanDamage(full)
  detect()
  local b, d = {}, {}
  if feat.breaks then
    for _, cid in ipairs(beamIds) do
      if obj:beamIsBroken(cid) and (full or not sentBroken[cid]) then
        sentBroken[cid] = true
        b[#b + 1] = cid
      end
    end
  end
  if feat.deform then
    for _, cid in ipairs(beamIds) do
      local base = baseLen[cid]
      if base and base > 0 and not (feat.breaks and obj:beamIsBroken(cid)) then
        local len = obj:getBeamRestLength(cid)
        local ref = full and base or (sentLen[cid] or base)
        if math.abs(len - ref) > base * DEFORM_THRESHOLD then
          sentLen[cid] = len
          d[#d + 1] = { cid, math.floor(len * 10000 + 0.5) / 10000 }
        end
      end
    end
  end
  sendDamage(b, d, full)
  -- totals, so the other player's copy can check it has the same damage
  local nb, nd = 0, 0
  for _, cid in ipairs(beamIds) do
    if feat.breaks and obj:beamIsBroken(cid) then nb = nb + 1
    elseif feat.deform then
      local base = baseLen[cid]
      if base and base > 0 and math.abs(obj:getBeamRestLength(cid) - base) > base * DEFORM_THRESHOLD then nd = nd + 1 end
    end
  end
  obj:queueGameEngineLua(string.format('beamp2p.onVehTotals(%d,%d,%d)', obj:getID(), nb, nd))
end

-- the game engine asks for this when a new player joins, so they see existing damage
local function sendFullDamage()
  fullDamageAt = clock + 2.0   -- give the newcomer time to spawn our car first
end

local function applyDamage(n, b, d)
  if not isRemote then return end
  detect()
  if n ~= #beamIds then
    warnOnce('damage', string.format('beam count differs (theirs %d, ours %d): different config, damage not applied', n, #beamIds))
    return
  end
  if feat.breaks then
    for _, cid in ipairs(b or {}) do
      if not obj:beamIsBroken(cid) then obj:breakBeam(cid) end
    end
  end
  if feat.deform then
    for _, e in ipairs(d or {}) do
      if not (feat.breaks and obj:beamIsBroken(e[1])) then obj:setBeamRestLength(e[1], e[2]) end
    end
  end
end

-- ---------- sync diagnostics: build + send one sample ----------
local function applyOwnerTotals(b, d)
  if isRemote then ownerDmg = { b, d } end
end

local function sendSample()
  local n = math.max(st.n, 1)
  local ev = electrics and electrics.values or {}
  -- this copy's own damage, counted the same way the owner counts theirs
  local cb, cd = -1, -1
  if feat then
    cb, cd = 0, 0
    for _, cid in ipairs(beamIds) do
      if feat.breaks and obj:beamIsBroken(cid) then cb = cb + 1
      elseif feat.deform then
        local base = baseLen[cid]
        if base and base > 0 and math.abs(obj:getBeamRestLength(cid) - base) > base * DEFORM_THRESHOLD then cd = cd + 1 end
      end
    end
  end
  local s = {
    n = st.n,                                  -- frames measured
    pe = st.pe / n, pm = st.pm,                -- position gap: average, worst (m)
    ve = st.ve / n,                            -- speed gap (m/s)
    ae = st.ae / n, am = st.am,                -- facing gap: average, worst (deg)
    ue = st.ue / n,                            -- upright gap (deg)
    se = st.se / n,                            -- spin gap (deg/s)
    sp = st.sp / n, cs = st.cs / n,            -- owner's speed vs copy's speed (m/s)
    ag = st.ag / n, lt = (tgt and tgt.lat or 0) * 1000, -- packet age, network lag (ms)
    pr = pktCount / SAMPLE_INTERVAL,           -- owner updates per second
    pu = st.pu / n, tw = st.tw / n,            -- correction push (m/s^2), twist (rad/s^2)
    cp = 100 * st.capped / n,                  -- % of frames the correction hit its cap
    tp = tpTotal, tr = tpLastReason,           -- teleports so far, last reason
    ob = ownerDmg and ownerDmg[1] or -1, cb = cb,   -- broken beams: owner vs copy
    od = ownerDmg and ownerDmg[2] or -1, cd = cd,   -- bent beams: owner vs copy
    it = ownerIn.thr, ct = ev.throttle_input or ev.throttle or 0,      -- throttle owner vs copy
    is = ownerIn.steer, cst = ev.steering_input or 0,                  -- steering owner vs copy
    ow = ownerIn.ws, cw = ev.wheelspeed or 0,                          -- wheel speed owner vs copy
    orpm = ownerIn.rpm, crpm = ev.rpm or 0,                            -- engine rpm owner vs copy
  }
  -- where this copy is right now: the owner's launcher checks it against where the
  -- owner's car really was at this moment (independent of this copy's prediction)
  s.px, s.py, s.pz = obj:getPositionXYZ()
  obj:queueGameEngineLua('beamp2p.onSyncSample(' .. obj:getID() .. ',' .. serialize(s) .. ')')
  resetStats()
  pktCount = 0
end

-- vehicle reset (repair): damage is gone, start reporting from scratch
local function onReset()
  sentBroken, sentLen = {}, {}
  prevMy, mySpin, cogRel = nil, { 0, 0, 0 }, nil
  farSince, flippedSince = nil, nil
end

-- ---------- update ----------
local function updateGFX(dt)
  if isRemote then
    local ok, err = pcall(sync, dt)
    if not ok then warnOnce('sync', err) end
    sampleTimer = sampleTimer - dt
    if sampleTimer <= 0 then
      sampleTimer = SAMPLE_INTERVAL
      if tgt and st.n > 0 then
        local sok, serr = pcall(sendSample)
        if not sok then warnOnce('sample', serr) end
      else
        resetStats(); pktCount = 0
      end
    end
  elseif isOwned then
    reportTimer = reportTimer - dt
    if reportTimer <= 0 then
      reportTimer = REPORT_INTERVAL
      local ok, err = pcall(report)
      if not ok then warnOnce('report', err) end
    end
    damageTimer = damageTimer - dt
    if damageTimer <= 0 then
      damageTimer = DAMAGE_INTERVAL
      local full = fullDamageAt ~= nil and clock >= fullDamageAt
      if full then fullDamageAt = nil end
      local ok, err = pcall(scanDamage, full)
      if not ok then warnOnce('damage scan', err) end
    end
  end
  clock = clock + dt
end

M.setRemote = setRemote
M.setOwned = setOwned
M.applyState = applyState
M.applyInputs = applyInputs
M.applyOwnerTotals = applyOwnerTotals
M._detect = function() detect() end
M.applyDamage = function(n, b, d)
  local ok, err = pcall(applyDamage, n, b, d)
  if not ok then warnOnce('apply damage', err) end
end
M.sendFullDamage = sendFullDamage
M.onReset = onReset
M.updateGFX = updateGFX

return M
