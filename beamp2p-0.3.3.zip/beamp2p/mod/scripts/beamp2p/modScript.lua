-- Loads the BeamP2P game-engine extension when the mod is active.
load('beamp2p')
setExtensionUnloadMode('beamp2p', 'manual')
