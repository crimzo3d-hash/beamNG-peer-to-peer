// BeamP2P sync diagnostics.
// Each player's game measures every copy of another player's car against that player's
// real (lag-corrected) car, twice a second. Those samples are:
//   - logged here as "their car on MY screen", and
//   - sent to the car's owner, who logs them as "MY car on their screen".
// So both launchers can show, for both directions, how closely the two screens agree.
'use strict';

const fs = require('fs');
const path = require('path');

// sample fields, in CSV column order: [key, description]
const FIELDS = [
  ['n', 'frames measured'],
  ['pe', 'position gap avg (m)'], ['pm', 'position gap worst (m)'],
  ['ve', 'speed gap avg (m/s)'],
  ['ae', 'facing gap avg (deg)'], ['am', 'facing gap worst (deg)'],
  ['ue', 'upright gap avg (deg)'], ['se', 'spin gap avg (deg/s)'],
  ['sp', 'owner speed (m/s)'], ['cs', 'copy speed (m/s)'],
  ['ag', 'packet age (ms)'], ['lt', 'network lag (ms)'], ['pr', 'updates per s'],
  ['pu', 'correction push (m/s2)'], ['tw', 'correction twist (rad/s2)'], ['cp', 'correction capped (%)'],
  ['tp', 'teleports total'], ['tr', 'last teleport reason (1 instant, 2 far, 3 flipped)'],
  ['ob', 'owner broken beams'], ['cb', 'copy broken beams'],
  ['od', 'owner bent beams'], ['cd', 'copy bent beams'],
  ['it', 'owner throttle'], ['ct', 'copy throttle'],
  ['is', 'owner steering'], ['cst', 'copy steering'],
  ['ow', 'owner wheel speed'], ['cw', 'copy wheel speed'],
  ['orpm', 'owner rpm'], ['crpm', 'copy rpm'],
  ['px', 'copy position x'], ['py', 'copy position y'], ['pz', 'copy position z'],
  ['tg', 'TRUE gap checked by owner (m)'],
];
const KEYS = FIELDS.map(f => f[0]);

// keep only known numeric fields, clamped to sane ranges
function cleanSample(s) {
  if (!s || typeof s !== 'object') return null;
  const out = {};
  for (const k of KEYS) {
    const v = s[k];
    out[k] = (typeof v === 'number' && Number.isFinite(v)) ? Math.max(-1e6, Math.min(1e6, v)) : null;
  }
  return out;
}

function stamp() {
  const d = new Date(), p = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
}

function createSyncLog({ dir, log, getName }) {
  let csv = null, summaryFile = null;
  const windows = new Map();   // `${peerId}|${dir}` -> samples since last summary
  const latest = new Map();    // `${peerId}|${dir}` -> last summary numbers (for the window)

  function open() {
    if (csv) return;
    try {
      fs.mkdirSync(dir, { recursive: true });
      const who = String((getName && getName()) || 'me').replace(/[^\w\-]/g, '_');
      const base = path.join(dir, `sync-${who}-${stamp()}`);
      csv = fs.createWriteStream(base + '.csv');
      csv.write(['time', 'direction', 'player', 'car', ...FIELDS.map(f => `${f[0]} (${f[1]})`)].map(q).join(',') + '\n');
      summaryFile = fs.createWriteStream(base + '-summary.txt');
      log(`Sync log: ${base}.csv`);
    } catch (e) {
      log('Could not create sync log:', e.message);
    }
  }
  function q(x) { const s = String(x); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }

  // direction: 'seen' = their car on my screen; 'me' = my car on their screen
  function add(direction, peerId, peerName, vid, sample) {
    const s = cleanSample(sample);
    if (!s) return null;
    open();
    if (csv) {
      const label = direction === 'seen' ? `their car on my screen` : `my car on their screen`;
      csv.write([new Date().toISOString(), label, peerName, vid, ...KEYS.map(k => s[k] == null ? '' : +s[k].toFixed(4))].map(q).join(',') + '\n');
    }
    const key = `${peerId}|${direction}`;
    if (!windows.has(key)) windows.set(key, { name: peerName, samples: [] });
    const w = windows.get(key);
    w.name = peerName;
    w.samples.push(s);
    return s;
  }

  // owner's check of a copy we reported on ('seen' direction) arrives a moment later
  function addTrueGap(peerId, peerName, tg) {
    if (typeof tg !== 'number' || !Number.isFinite(tg)) return;
    const key = `${peerId}|seen`;
    if (!windows.has(key)) windows.set(key, { name: peerName, samples: [] });
    const w = windows.get(key);
    (w.trueGaps = w.trueGaps || []).push(Math.max(0, Math.min(1e6, tg)));
  }

  function avg(arr, k) {
    const v = arr.map(s => s[k]).filter(x => x != null);
    return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
  }
  function max(arr, k) {
    const v = arr.map(s => s[k]).filter(x => x != null);
    return v.length ? Math.max(...v) : null;
  }
  function rel(a, b) { return (a == null || b == null) ? null : Math.abs(a - b) / Math.max(Math.abs(a), 1); }

  function summarise(w) {
    const S = w.samples;
    const first = S[0], last = S[S.length - 1];
    const r = {
      pe: avg(S, 'pe'), pm: max(S, 'pm'), ae: avg(S, 'ae'), am: max(S, 'am'), ue: avg(S, 'ue'),
      ve: avg(S, 've'), sp: avg(S, 'sp'),
      tp: (last.tp != null && first.tp != null) ? Math.max(0, last.tp - first.tp) : 0,
      tpTotal: last.tp,
      ob: last.ob, cb: last.cb, od: last.od, cd: last.cd,
      thr: avg(S.map(s => ({ x: (s.it != null && s.ct != null) ? Math.abs(s.it - s.ct) : null })), 'x'),
      steer: avg(S.map(s => ({ x: (s.is != null && s.cst != null) ? Math.abs(s.is - s.cst) : null })), 'x'),
      wheels: avg(S.map(s => ({ x: rel(s.ow, s.cw) })), 'x'),
      rpm: avg(S.map(s => ({ x: rel(s.orpm, s.crpm) })), 'x'),
      pr: avg(S, 'pr'), lt: avg(S, 'lt'), ag: avg(S, 'ag'), cp: avg(S, 'cp'),
    };
    // true gap: on 'me' it's in the samples; on 'seen' it came back from the owner
    const tgs = (w.trueGaps && w.trueGaps.length) ? w.trueGaps : S.map(x => x.tg).filter(x => x != null);
    r.tg = tgs.length ? tgs.reduce((a, b) => a + b, 0) / tgs.length : null;
    r.tgMax = tgs.length ? Math.max(...tgs) : null;
    w.trueGaps = [];
    // a teleport between the previous window and this one counts too
    if (w.prevTp != null && first.tp != null) r.tp += Math.max(0, first.tp - w.prevTp);
    w.prevTp = last.tp;
    const gap = r.tg != null ? r.tg : r.pe;   // judge by the owner-checked gap when we have it
    r.verdict = (gap != null && gap < 1 && r.tp === 0 && (r.am == null || r.am < 30)) ? 'GOOD'
      : (gap != null && gap < 3 && r.tp <= 1) ? 'OK' : 'BAD';
    return r;
  }

  function f(x, d = 1) { return x == null ? '?' : x.toFixed(d); }
  function pct(x) { return x == null ? '?' : Math.round(x * 100) + '%'; }
  function dmg(o, c) { return (o == null || o < 0 || c == null || c < 0) ? 'n/a' : `${c}/${o}`; }

  function line(direction, name, r, secs) {
    const who = direction === 'seen' ? `${name}'s car on YOUR screen` : `YOUR car on ${name}'s screen`;
    return `[sync ${r.verdict}] ${who} (last ${secs}s): ` +
      `TRUE gap ${f(r.tg, 2)} m (worst ${f(r.tgMax, 2)}, checked by the car's owner), ` +
      `${f(r.pe, 2)} m off its prediction (worst ${f(r.pm, 2)}), facing ${f(r.ae)}° (worst ${f(r.am)}°), upright ${f(r.ue)}°, ` +
      `speed gap ${f(r.ve, 2)} m/s, ${r.tp} teleport(s) | ` +
      `damage broken ${dmg(r.ob, r.cb)}, bent ${dmg(r.od, r.cd)} | ` +
      `throttle Δ${f(r.thr, 2)}, steering Δ${f(r.steer, 2)}, wheels ${pct(r.wheels)} off, rpm ${pct(r.rpm)} off | ` +
      `${f(r.pr, 0)} updates/s, lag ${f(r.lt, 0)} ms, correction capped ${f(r.cp, 0)}%` + warnings(r);
  }

  // plain-English flags for things worth knowing
  function warnings(r) {
    const w = [];
    if (r.ob >= 0 && r.cb >= 0 && r.cb - r.ob > 10)
      w.push(`copy has ${r.cb - r.ob} more broken beams than the real car (it crashed on this screen only)`);
    if (r.ob >= 0 && r.cb >= 0 && r.ob - r.cb > 10)
      w.push(`copy is missing ${r.ob - r.cb} broken beams the real car has (damage not arriving)`);
    if (r.pr != null && r.pr < 15) w.push(`only ${Math.round(r.pr)} updates/s (low FPS or connection trouble on the owner's side)`);
    if (r.cp != null && r.cp > 25) w.push(`correction hitting its limit ${Math.round(r.cp)}% of the time (copy being held back or stuck)`);
    if (r.tp > 0) w.push(`${r.tp} teleport(s) (copy got too far off)`);
    return w.length ? ' | ⚠ ' + w.join('; ') : '';
  }

  // called every few seconds: print + store one line per player per direction
  function report(secs) {
    for (const [key, w] of windows) {
      if (!w.samples.length) { w.trueGaps = []; continue; }
      const [peerId, direction] = key.split('|');
      const r = summarise(w);
      latest.set(key, { ...r, at: Date.now() });
      const text = line(direction, w.name, r, secs);
      log(text);
      if (summaryFile) summaryFile.write(new Date().toISOString() + ' ' + text + '\n');
      w.samples = [];
    }
  }

  // short numbers for the launcher window's player list
  function statsFor(peerId) {
    const pick = (dir) => {
      const r = latest.get(`${peerId}|${dir}`);
      if (!r || Date.now() - r.at > 30000) return null;
      const g = r.tg != null ? r.tg : r.pe;
      return { verdict: r.verdict, pe: g == null ? null : +g.toFixed(2), tp: r.tpTotal };
    };
    return { seen: pick('seen'), me: pick('me') };
  }

  function forget(peerId) {
    for (const key of [...windows.keys()]) if (key.startsWith(peerId + '|')) windows.delete(key);
  }

  function close() {
    try { if (csv) csv.end(); if (summaryFile) summaryFile.end(); } catch {}
    csv = summaryFile = null;
  }

  return { add, addTrueGap, report, statsFor, forget, close, cleanSample };
}

module.exports = { createSyncLog, FIELDS };
