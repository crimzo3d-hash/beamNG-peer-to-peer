#!/usr/bin/env bash
# BeamP2P launcher for Linux
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 18 or newer is required. Install it from your package manager (e.g. 'sudo pacman -S nodejs npm' or 'sudo apt install nodejs npm')."
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "First run: installing dependencies..."
  npm install --omit=dev || exit 1
fi
exec node launcher.js "$@"
