# BeamP2P

Peer-to-peer multiplayer for BeamNG.drive. No server to host or pay for: you type a room name and password, your friends type the same, and you find each other directly. Works on Linux (native build or Proton) and Windows.

## Playing

1. Install [Node.js](https://nodejs.org) 18 or newer (once).
2. Run `start.sh` (Linux) or double-click `start.bat` (Windows).
   - The first run installs dependencies and copies the mod into your BeamNG `mods/unpacked/beamp2p` folder.
3. A launcher page opens in your browser. Enter your name, a room name and a password, then click **Join room**. Leave the terminal open; closing it quits the launcher.
   - Prefer the terminal? Run with `--cli`, or pass `--room` and `--password`.
4. Start BeamNG.drive, make sure the **beamp2p** mod is enabled, and load a map. Everyone should load the same map.
5. Spawn a car. Friends' cars appear as they spawn theirs.

Chat from the launcher page; messages show in-game. **Reset others' cars** repairs every other player's car and puts it back where its owner really is (also bindable in-game under Options → Controls → BeamP2P).

Options: `--cli`, `--debug`, `--no-browser`, `--ui-port 4460`, `--name`, `--room`, `--password`, `--max-players 8`, `--port 4455`, `--mods "<path to mods folder>"` (if auto-detect misses your install), `--no-install`, `--install-only`.

## How it works

- **No central server.** Peers meet on the public Hyperswarm DHT, a distributed network with no owner. It uses UDP hole punching to connect players directly, so no port forwarding is needed in most cases.
- **The launcher** bridges the game, over localhost port 4455, and the peers. Every player connects to every other player, and nobody is the host.
- **The mod** sends your cars' position, speed, facing, spin, controls and lights 30 times a second. Other players' copies are *state-driven*: every frame they're pushed toward the owner's real position, speed and rotation, predicted ahead by the measured lag (the same approach as BeamMP). Controls are replayed only so wheels, steering and lights look right. If a copy still ends up well off (about 2.5 m + 0.3 m per m/s for 1.5 s, 6 m instantly, or facing over 90° wrong for 1.5 s), it's moved straight there without repairing it.
- **Damage sync:** twice a second your car reports newly broken and bent *structural* beams (parts falling off, glass, dents). Hydraulics, suspension and pressure beams are never synced, because they change length during normal driving. It only applies between identical cars (same model and config); otherwise it's skipped and logged.
- **The launcher page** is served only on 127.0.0.1 and needs a random token in its link, so other websites can't control it. Name and recent rooms are saved in `~/.config/beamp2p/config.json` (Windows: `%APPDATA%\beamp2p`); passwords never are.

## Sync diagnostics

Every copy of another player's car measures itself against that player's real car twice a second: position, speed, facing, upright angle, spin, broken/bent beams, throttle, steering, wheel speed, engine rpm, lag, update rate, how hard it's being corrected and any teleports. Each launcher:

- logs **"their car on my screen"** from its own game, and sends it to the car's owner;
- logs **"my car on their screen"** from what other players send back.

Every 10 s the launcher prints a summary for both directions, e.g. `[sync GOOD] Tompa's car on YOUR screen: 0.30 m off avg (worst 0.80), facing 2.5° … damage broken 118/120 …`, and the player list in the launcher window shows a `them` / `you` badge (GOOD / OK / BAD). Full detail is in `logs/sync-<name>-<time>.csv` (one row per car per half-second) and `-summary.txt`.

`--debug` also logs every network link opening and closing.

## Security

- The room is located by a key derived from **room name + password** with scrypt. Without the password you can't even find the room, and the slow key derivation makes guessing expensive.
- All traffic is end-to-end encrypted (Noise protocol, built into Hyperswarm).
- Each new peer must prove it knows the password with an HMAC challenge, tied to that specific encrypted connection, before anything is accepted. Failing peers are dropped after 10 seconds.
- Incoming messages are allow-listed and type-checked. Peers can only send car spawns, car states, damage, resets, map name, chat and sync reports (numbers only); they can never send Lua code. Messages are size-capped, and peers that flood are disconnected.
- Use a long, unique password (10+ characters). Anyone who has the password can join.
- Your IP address is visible to the other players in the room, as with any direct P2P game.

## Limitations (v0.3)

- Each screen also works out its own crash physics, so dents can differ slightly; the sync log's `broken`/`bent` columns show by how much. Check `beamng.log` for `damage sync:` to see which parts are active on your game version.
- Everyone needs the same vehicle mods and the same map. A warning shows if maps differ.
- Very strict NATs, such as some mobile hotspots and CGNAT on both sides, may fail to connect, because there's no relay.
- Some BeamNG Lua APIs this relies on can change between game updates. Check `beamng.log` for lines tagged `beamp2p` if something stops working.
