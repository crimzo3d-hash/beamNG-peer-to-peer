-- BeamP2P: game-engine side. Talks to the BeamP2P launcher over localhost
-- and keeps remote players' cars in sync with ours.
local M = {}

local MOD_VERSION = '0.2.0'
local socket = require('socket')

local HOST, PORT = '127.0.0.1', 4455
local SEND_INTERVAL = 0.05      -- 20 state updates per second
local RECONNECT_INTERVAL = 2.0
local SNAP_DISTANCE = 100       -- metres; only teleport a remote car if it is this far off

local sock = nil
local rxBuf = ''
local reconnectTimer = 0
local sendTimer = 0

local remote = {}        -- "peer:vid" -> { id = localVehId, peer = peerId, last = msg, rxTime = t }
local remoteIds = {}     -- localVehId -> "peer:vid"
local peerNames = {}     -- peerId -> name
local pendingSpawn = {}  -- localVehId -> true (owned vehicles whose spawn we still need to announce)
local inputs = {}        -- localVehId -> latest input/electrics table from vehicle lua
local owned = {}         -- localVehId -> true for cars the player has driven (traffic/parked cars are never synced)
local spawningRemote = false

local function now() return socket.gettime() end

local function msg(text, time)
  if ui_message then ui_message(text, time or 5, 'beamp2p') end
  log('I', 'beamp2p', text)
end

local function send(tbl)
  if not sock then return end
  local ok, err = sock:send(jsonEncode(tbl) .. '\n')
  if not ok and err == 'closed' then sock = nil; msg('BeamP2P: lost connection to launcher') end
end

local function isRemote(id) return remoteIds[id] ~= nil end

local function ownedVehicles()
  local list = {}
  for id in pairs(owned) do
    local veh = be:getObjectByID(id)
    if veh then table.insert(list, veh) else owned[id] = nil end
  end
  return list
end

-- tell a car's own Lua that it's ours (it then reports inputs and damage)
local function markOwned(veh)
  veh:queueLuaCommand('extensions.load("beamp2pVeh")')
  veh:queueLuaCommand('beamp2pVeh.setOwned(true)')
end

-- the car you're sitting in becomes yours to sync
local function claimPlayerVehicle()
  local veh = be:getPlayerVehicle(0)
  if not veh then return end
  local id = veh:getID()
  if isRemote(id) or owned[id] then return end
  owned[id] = true
  pendingSpawn[id] = true
  markOwned(veh)
end

local function partConfigOf(veh)
  local pc = veh.partConfig
  if (pc == nil or pc == '') and veh.getField then pc = veh:getField('partConfig', '') end
  return type(pc) == 'string' and pc or ''
end

-- current facing of the physics body (veh:getRotation() is only the spawn transform)
local function rotationOf(veh)
  local dir, up = veh:getDirectionVector(), veh:getDirectionVectorUp()
  return quatFromDir(-vec3(dir.x, dir.y, dir.z), vec3(up.x, up.y, up.z))
end

local function transformOf(veh)
  local p = veh:getPosition()
  local r = rotationOf(veh)
  local v = veh:getVelocity()
  return { p.x, p.y, p.z }, { r.x, r.y, r.z, r.w }, { v.x, v.y, v.z }
end

local function ensureVehLua(veh)
  veh:queueLuaCommand('extensions.load("beamp2pVeh")')
end

-- ---------- owned vehicles -> network ----------
local function announceSpawn(veh)
  local p, r = transformOf(veh)
  send({ t = 'spawn', vid = veh:getID(), model = veh:getJBeamFilename(), config = partConfigOf(veh), p = p, r = r })
end

local function sendStates()
  claimPlayerVehicle()
  for _, veh in ipairs(ownedVehicles()) do
    local id = veh:getID()
    if pendingSpawn[id] then pendingSpawn[id] = nil; announceSpawn(veh) end
    local p, r, v = transformOf(veh)
    local inp = inputs[id] or {}
    send({ t = 'state', vid = id, p = p, r = r, v = v, i = inp.i, e = inp.e })
  end
end

-- called from vehicle lua with that vehicle's controls and electrics
M.onVehInput = function(id, data)
  if type(data) == 'table' then inputs[id] = data end
end

-- called from vehicle lua with newly broken / bent beams on one of our cars
M.onVehDamage = function(id, data)
  if not owned[id] or type(data) ~= 'table' then return end
  send({ t = 'damage', vid = id, n = data.n, b = data.b or {}, d = data.d or {}, full = data.full == true })
end

-- ---------- network -> remote vehicles ----------
local function deleteRemote(key)
  local r = remote[key]
  if not r then return end
  local veh = be:getObjectByID(r.id)
  remoteIds[r.id] = nil
  remote[key] = nil
  if veh then veh:delete() end
end

local function spawnRemote(key, m)
  deleteRemote(key)
  -- part config arrives either as a .pc path or as a serialized table
  local config = m.config
  if type(config) == 'string' then
    if config:sub(1, 1) == '{' and deserialize then
      local ok, t = pcall(deserialize, config)
      config = (ok and type(t) == 'table') and t or nil
    elseif not config:match('%.pc$') then
      config = nil
    end
  end
  local player = be:getPlayerVehicle(0)
  local function trySpawn(cfg)
    spawningRemote = true
    local ok, v = pcall(core_vehicles.spawnNewVehicle, m.model, {
      config = cfg,
      pos = vec3(m.p[1], m.p[2], m.p[3]),
      rot = quat(m.r[1], m.r[2], m.r[3], m.r[4]),
      autoEnterVehicle = false,
      cling = false,
    })
    spawningRemote = false
    if not ok then log('E', 'beamp2p', 'spawn ' .. tostring(m.model) .. ' failed: ' .. tostring(v)) end
    return ok and v or nil
  end
  local veh = trySpawn(config)
  if not veh and config ~= nil then
    log('W', 'beamp2p', 'retrying ' .. tostring(m.model) .. ' with default config')
    veh = trySpawn(nil)
  end
  local ok = veh ~= nil
  if not ok or not veh then
    msg('BeamP2P: could not spawn ' .. tostring(m.model) .. ' (missing mod?)')
    return
  end
  local id = veh:getID()
  remote[key] = { id = id, peer = m.from, rxTime = now() }
  remoteIds[id] = key
  pendingSpawn[id] = nil
  ensureVehLua(veh)
  veh:queueLuaCommand('beamp2pVeh.setRemote(true)')
  if player and be:getPlayerVehicle(0) ~= player then be:enterVehicle(0, player) end
  local who = peerNames[m.from] or 'Someone'
  msg('BeamP2P: ' .. who .. ' spawned ' .. m.model, 3)
end

local function applyState(key, m)
  local r = remote[key]
  if not r then return end
  local veh = be:getObjectByID(r.id)
  if not veh then remote[key] = nil; remoteIds[r.id] = nil; return end
  local t = now()
  r.last = m
  r.rxTime = t
  -- Normal drift is handled only by the smooth vehicle-side pull: no automatic teleports.
  -- Snaps happen only after a reset (the owner's, or yours via the reset key) or when the
  -- owner is over SNAP_DISTANCE away (map teleport), which a smooth pull could never close.
  local pos = veh:getPosition()
  local dx, dy, dz = m.p[1] - pos.x, m.p[2] - pos.y, m.p[3] - pos.z
  local forced = r.forceSnapAt and t >= r.forceSnapAt
  if forced or dx * dx + dy * dy + dz * dz > SNAP_DISTANCE * SNAP_DISTANCE then
    veh:setPositionRotation(m.p[1], m.p[2], m.p[3], m.r[1], m.r[2], m.r[3], m.r[4])
    -- carry the owner's speed through the snap so it doesn't fall behind again
    veh:queueLuaCommand(string.format('beamp2pVeh.matchVelocity(%f,%f,%f)', m.v[1], m.v[2], m.v[3]))
    r.forceSnapAt = nil
  end
  local i, e = m.i or {}, m.e or {}
  veh:queueLuaCommand(string.format(
    'beamp2pVeh.applyState(%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f)',
    m.p[1], m.p[2], m.p[3], m.v[1], m.v[2], m.v[3],
    i.throttle or 0, i.brake or 0, i.steering or 0, i.parkingbrake or 0,
    e.lights or 0, e.horn or 0, e.signal_L or 0, e.signal_R or 0))
end

local function handle(m)
  local t = m.t
  local key = m.vid and (tostring(m.from) .. ':' .. tostring(m.vid))
  if t == 'state' then
    if remote[key] then applyState(key, m) end
  elseif t == 'spawn' then
    spawnRemote(key, m)
  elseif t == 'remove' then
    deleteRemote(key)
  elseif t == 'reset' then
    -- owner reset (repaired) their car: repair ours, then place it on their next update
    local r = remote[key]
    local veh = r and be:getObjectByID(r.id)
    if veh then
      veh:queueLuaCommand('obj:requestReset(RESET_PHYSICS)')
      r.forceSnapAt = now() + 0.2
    end
  elseif t == 'reset_remote' then
    M.resetRemoteCars()
  elseif t == 'damage' then
    local r = remote[key]
    local veh = r and be:getObjectByID(r.id)
    if veh and type(m.b) == 'table' and type(m.d) == 'table' then
      -- split big updates so a single Lua command stays small
      local CH = 300
      local nb, nd = #m.b, #m.d
      local i, j = 1, 1
      repeat
        local cb, cd = {}, {}
        while i <= nb and #cb < CH do cb[#cb + 1] = m.b[i]; i = i + 1 end
        while j <= nd and #cb + #cd < CH do cd[#cd + 1] = m.d[j]; j = j + 1 end
        veh:queueLuaCommand(string.format('beamp2pVeh.applyDamage(%d,%s,%s)', m.n or 0, serialize(cb), serialize(cd)))
      until i > nb and j > nd
    end
  elseif t == 'peer_join' then
    peerNames[m.from] = m.name
    msg('BeamP2P: ' .. tostring(m.name) .. ' joined')
  elseif t == 'peer_leave' then
    for k, r in pairs(remote) do if r.peer == m.from then deleteRemote(k) end end
    msg('BeamP2P: ' .. tostring(peerNames[m.from] or 'A player') .. ' left')
    peerNames[m.from] = nil
  elseif t == 'resync' then
    for id in pairs(owned) do
      pendingSpawn[id] = true
      local veh = be:getObjectByID(id)
      if veh then veh:queueLuaCommand('beamp2pVeh.sendFullDamage()') end
    end
    if getMissionFilename then send({ t = 'map', map = getMissionFilename() }) end
  elseif t == 'map' then
    local mine = getMissionFilename and getMissionFilename() or ''
    if mine ~= '' and m.map ~= mine then
      msg('BeamP2P: ' .. tostring(peerNames[m.from] or 'A player') .. ' is on a different map: ' .. tostring(m.map), 8)
    end
  elseif t == 'chat' then
    local who = m.from == 'me' and 'You' or (peerNames[m.from] or '?')
    msg(who .. ': ' .. tostring(m.text), 8)
  elseif t == 'welcome' then
    msg('BeamP2P: connected to launcher as ' .. tostring(m.name))
  end
end

-- ---------- socket ----------
local function tryConnect()
  local s = socket.tcp()
  s:settimeout(0.05)
  local ok = s:connect(HOST, PORT)
  if not ok then s:close(); return end
  s:settimeout(0)
  s:setoption('tcp-nodelay', true)
  sock = s
  rxBuf = ''
  -- announce the car we're in, plus any we drove earlier
  claimPlayerVehicle()
  for _, veh in ipairs(ownedVehicles()) do pendingSpawn[veh:getID()] = true; markOwned(veh) end
  if getMissionFilename then send({ t = 'map', map = getMissionFilename() }) end
end

local function receive()
  for _ = 1, 500 do
    local line, err, partial = sock:receive('*l')
    if line then
      line = rxBuf .. line
      rxBuf = ''
      local ok, m = pcall(jsonDecode, line)
      if ok and type(m) == 'table' then
        local hok, herr = pcall(handle, m)
        if not hok then log('E', 'beamp2p', tostring(herr)) end
      end
    elseif err == 'timeout' then
      if partial and partial ~= '' then rxBuf = rxBuf .. partial end
      return
    else
      sock:close(); sock = nil
      msg('BeamP2P: launcher closed the connection')
      return
    end
  end
end

-- ---------- hooks ----------
M.onUpdate = function(dtReal)
  if not sock then
    reconnectTimer = reconnectTimer - dtReal
    if reconnectTimer <= 0 then reconnectTimer = RECONNECT_INTERVAL; tryConnect() end
    return
  end
  receive()
  if not sock then return end
  sendTimer = sendTimer - dtReal
  if sendTimer <= 0 then sendTimer = SEND_INTERVAL; sendStates() end
end

M.onVehicleSpawned = function(id)
  local veh = be:getObjectByID(id)
  if not veh then return end
  if spawningRemote or isRemote(id) then return end
  ensureVehLua(veh)
  -- config change respawns an owned car under the same id (fresh Lua): re-announce it
  if owned[id] then pendingSpawn[id] = true; markOwned(veh) end
end

M.onVehicleDestroyed = function(id)
  inputs[id] = nil
  pendingSpawn[id] = nil
  local key = remoteIds[id]
  if key then remoteIds[id] = nil; remote[key] = nil
  elseif owned[id] then owned[id] = nil; send({ t = 'remove', vid = id }) end
end

M.onVehicleResetted = function(id)
  if owned[id] then send({ t = 'reset', vid = id }) end
end

M.onVehicleSwitched = function(oldId, newId, player)
  -- don't let the player drive someone else's car
  if isRemote(newId) then
    local old = oldId and oldId >= 0 and be:getObjectByID(oldId)
    if old then be:enterVehicle(player or 0, old) end
    msg('BeamP2P: that car belongs to another player', 3)
    return
  end
  if newId and newId >= 0 and not owned[newId] then
    owned[newId] = true
    pendingSpawn[newId] = true
    local veh = be:getObjectByID(newId)
    if veh then markOwned(veh) end
  end
end

-- bound to the "BeamP2P: reset other players' cars" control, and /reset in the launcher.
-- Repairs every remote car and places it on its owner's latest position.
M.resetRemoteCars = function()
  local n = 0
  for _, r in pairs(remote) do
    local veh = be:getObjectByID(r.id)
    if veh then
      veh:queueLuaCommand('obj:requestReset(RESET_PHYSICS)')
      r.forceSnapAt = now() + 0.2
      n = n + 1
    end
  end
  msg('BeamP2P: reset ' .. n .. ' other player car(s)', 3)
end

M.onExtensionLoaded = function()
  log('I', 'beamp2p', 'BeamP2P mod ' .. MOD_VERSION .. ' loaded')
end

M.onClientPostStartMission = function()
  if getMissionFilename then send({ t = 'map', map = getMissionFilename() }) end
end

M.onClientEndMission = function()
  remote, remoteIds, inputs, pendingSpawn, owned = {}, {}, {}, {}, {}
end

M.onExtensionUnloaded = function()
  if sock then sock:close(); sock = nil end
end

return M
