-- BeamP2P: vehicle side (runs inside each car's own Lua VM).
-- Your cars: report inputs/electrics and damage (broken + bent beams) to the game engine.
-- Remote cars: replay the owner's inputs, nudge velocity toward the owner's
-- position, and apply the owner's damage.
local M = {}

local isRemote = false
local isOwned = false
local reportTimer = 0
local target = nil      -- { px,py,pz, vx,vy,vz, t }
local clock = 0
local warned = {}

local CORRECT_POS = 2.0   -- how hard to pull toward the target position (1/s)
local CORRECT_VEL = 0.6   -- how much of the velocity error to remove per step
local MAX_NUDGE = 4.0     -- m/s max correction per update

local DAMAGE_INTERVAL = 0.5   -- seconds between damage scans on your own car
local DEFORM_THRESHOLD = 0.005 -- a beam counts as bent once its rest length changes by 0.5%
local DAMAGE_CHUNK = 400      -- items per message

local function warnOnce(key, err)
  if warned[key] then return end
  warned[key] = true
  log('E', 'beamp2pVeh', key .. ': ' .. tostring(err))
end

local function refNode()
  local rn = v and v.data and v.data.refNodes and v.data.refNodes[0]
  return rn and rn.ref or 0
end

local function setRemote(on)
  isRemote = on and true or false
  if isRemote and ai and ai.setMode then pcall(ai.setMode, 'disabled') end
end

local function setOwned(on) isOwned = on and true or false end

-- ---------- driving ----------
local function inputEvent(name, value)
  if input and input.event then
    local ok, err = pcall(input.event, name, value, 2)
    if not ok then warnOnce('input.' .. name, err) end
  end
end

local function applyState(px, py, pz, vx, vy, vz, thr, brk, steer, pb, lights, horn, sigL, sigR)
  if not isRemote then return end
  target = { px, py, pz, vx, vy, vz, clock }
  inputEvent('throttle', thr)
  inputEvent('brake', brk)
  inputEvent('steering', steer)
  inputEvent('parkingbrake', pb)
  if electrics and electrics.values then
    if electrics.setLightsState then pcall(electrics.setLightsState, lights) end
    if electrics.horn then pcall(electrics.horn, horn > 0.5) end
    if electrics.toggle_left_signal then
      local ev = electrics.values
      if (sigL > 0.5) ~= ((ev.signal_left_input or 0) > 0.5) then pcall(electrics.toggle_left_signal) end
      if (sigR > 0.5) ~= ((ev.signal_right_input or 0) > 0.5) then pcall(electrics.toggle_right_signal) end
    end
  end
end

local function correct(dt)
  if not target then return end
  local age = clock - target[7]
  if age > 1.0 then return end   -- stale; wait for next packet
  local pos = obj:getPosition()
  local vel = obj:getVelocity()
  -- predict where the owner's car is now
  local tx = target[1] + target[4] * age
  local ty = target[2] + target[5] * age
  local tz = target[3] + target[6] * age
  local cx = (tx - pos.x) * CORRECT_POS + (target[4] - vel.x) * CORRECT_VEL
  local cy = (ty - pos.y) * CORRECT_POS + (target[5] - vel.y) * CORRECT_VEL
  local cz = (tz - pos.z) * CORRECT_POS + (target[6] - vel.z) * CORRECT_VEL
  local len = math.sqrt(cx * cx + cy * cy + cz * cz)
  if len > MAX_NUDGE then local s = MAX_NUDGE / len; cx, cy, cz = cx * s, cy * s, cz * s end
  local k = math.min(1, dt * 10)
  obj:applyClusterVelocityScaleAdd(refNode(), 1, cx * k, cy * k, cz * k)
end

local function report()
  local ev = electrics and electrics.values or {}
  local data = {
    i = {
      throttle = ev.throttle_input or ev.throttle or 0,
      brake = ev.brake_input or ev.brake or 0,
      steering = ev.steering_input or 0,
      parkingbrake = ev.parkingbrake_input or ev.parkingbrake or 0,
    },
    e = {
      lights = ev.lights_state or 0,
      horn = ev.horn or 0,
      signal_L = ev.signal_left_input or 0,
      signal_R = ev.signal_right_input or 0,
    },
  }
  obj:queueGameEngineLua('beamp2p.onVehInput(' .. obj:getID() .. ',' .. serialize(data) .. ')')
end

-- after a snap: set the whole car's velocity to the owner's (scale 0 = replace, not add)
local function matchVelocity(vx, vy, vz)
  if not isRemote then return end
  local ok, err = pcall(function() obj:applyClusterVelocityScaleAdd(refNode(), 0, vx, vy, vz) end)
  if not ok then warnOnce('matchVelocity', err) end
  if target then target[7] = clock end
end

-- ---------- damage ----------
-- Both cars must be the same model + config, so beam ids line up. The beam count
-- travels with every damage message and mismatching cars ignore each other's damage.
local feat = nil          -- { breaks = bool, deform = bool }
local beamIds = nil       -- sorted beam ids
local baseLen = {}        -- id -> undamaged rest length
local sentBroken = {}     -- id -> true once reported
local sentLen = {}        -- id -> last reported rest length
local damageTimer = 0
local fullDamageAt = nil  -- clock time to send a full damage snapshot

local function hasMethod(name)
  local ok, f = pcall(function() return obj[name] end)
  return ok and f ~= nil
end

local function detect()
  if feat then return end
  feat = {
    breaks = hasMethod('beamIsBroken') and hasMethod('breakBeam'),
    deform = hasMethod('getBeamRestLength') and hasMethod('setBeamRestLength'),
  }
  beamIds = {}
  for _, b in pairs((v and v.data and v.data.beams) or {}) do
    if type(b) == 'table' and b.cid then beamIds[#beamIds + 1] = b.cid end
  end
  table.sort(beamIds)
  if feat.deform and not isRemote then
    for _, cid in ipairs(beamIds) do baseLen[cid] = obj:getBeamRestLength(cid) end
  end
  log('I', 'beamp2pVeh', string.format('damage sync: %d beams, breaks=%s, deform=%s',
    #beamIds, tostring(feat.breaks), tostring(feat.deform)))
end

local function sendDamage(b, d, full)
  local n = #beamIds
  local nb, nd = #b, #d
  if nb == 0 and nd == 0 and not full then return end
  local i, j = 1, 1
  repeat
    local cb, cd = {}, {}
    while i <= nb and #cb < DAMAGE_CHUNK do cb[#cb + 1] = b[i]; i = i + 1 end
    while j <= nd and #cd + #cb < DAMAGE_CHUNK do cd[#cd + 1] = d[j]; j = j + 1 end
    obj:queueGameEngineLua(string.format('beamp2p.onVehDamage(%d,%s)', obj:getID(),
      serialize({ n = n, b = cb, d = cd, full = full and true or false })))
    full = false   -- only the first chunk of a snapshot is marked full
  until i > nb and j > nd
end

local function scanDamage(full)
  detect()
  local b, d = {}, {}
  if feat.breaks then
    for _, cid in ipairs(beamIds) do
      if obj:beamIsBroken(cid) and (full or not sentBroken[cid]) then
        sentBroken[cid] = true
        b[#b + 1] = cid
      end
    end
  end
  if feat.deform then
    for _, cid in ipairs(beamIds) do
      local base = baseLen[cid]
      if base and base > 0 then
        local len = obj:getBeamRestLength(cid)
        local ref = full and base or (sentLen[cid] or base)
        if math.abs(len - ref) > base * DEFORM_THRESHOLD then
          sentLen[cid] = len
          d[#d + 1] = { cid, math.floor(len * 10000 + 0.5) / 10000 }
        end
      end
    end
  end
  sendDamage(b, d, full)
end

-- the game engine asks for this when a new player joins, so they see existing damage
local function sendFullDamage()
  fullDamageAt = clock + 2.0   -- give the newcomer time to spawn our car first
end

local function applyDamage(n, b, d)
  if not isRemote then return end
  detect()
  if n ~= #beamIds then
    warnOnce('damage', string.format('beam count differs (theirs %d, ours %d): different config, damage not applied', n, #beamIds))
    return
  end
  if feat.breaks then
    for _, cid in ipairs(b or {}) do
      if not obj:beamIsBroken(cid) then obj:breakBeam(cid) end
    end
  end
  if feat.deform then
    for _, e in ipairs(d or {}) do obj:setBeamRestLength(e[1], e[2]) end
  end
end

-- vehicle reset (repair): damage is gone, start reporting from scratch
local function onReset()
  sentBroken, sentLen = {}, {}
end

-- ---------- update ----------
local function updateGFX(dt)
  clock = clock + dt
  if isRemote then
    local ok, err = pcall(correct, dt)
    if not ok then warnOnce('correct', err) end
  elseif isOwned then
    reportTimer = reportTimer - dt
    if reportTimer <= 0 then
      reportTimer = 0.05
      local ok, err = pcall(report)
      if not ok then warnOnce('report', err) end
    end
    damageTimer = damageTimer - dt
    if damageTimer <= 0 then
      damageTimer = DAMAGE_INTERVAL
      local full = fullDamageAt ~= nil and clock >= fullDamageAt
      if full then fullDamageAt = nil end
      local ok, err = pcall(scanDamage, full)
      if not ok then warnOnce('damage scan', err) end
    end
  end
end

M.matchVelocity = matchVelocity
M.setRemote = setRemote
M.setOwned = setOwned
M.applyState = applyState
M.applyDamage = function(n, b, d)
  local ok, err = pcall(applyDamage, n, b, d)
  if not ok then warnOnce('apply damage', err) end
end
M.sendFullDamage = sendFullDamage
M.onReset = onReset
M.updateGFX = updateGFX

return M
