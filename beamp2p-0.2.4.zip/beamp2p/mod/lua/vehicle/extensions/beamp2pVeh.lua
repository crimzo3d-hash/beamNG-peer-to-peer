-- BeamP2P: vehicle side (runs inside each car's own Lua VM).
-- Your cars: report inputs/electrics and damage (broken + bent beams) to the game engine.
-- Remote cars: replay the owner's inputs, nudge velocity toward the owner's
-- position, and apply the owner's damage.
local M = {}

local isRemote = false
local isOwned = false
local reportTimer = 0
local target = nil      -- { px,py,pz, vx,vy,vz, t }
local clock = 0
local warned = {}

local CORRECT_POS = 2.0   -- how hard to pull toward the target position (1/s)
local CORRECT_VEL = 0.6   -- how much of the velocity error to remove per step
local MAX_NUDGE = 4.0     -- m/s max correction per update

local DAMAGE_INTERVAL = 0.5   -- seconds between damage scans on your own car
local DEFORM_THRESHOLD = 0.005 -- a beam counts as bent once its rest length changes by 0.5%
local DAMAGE_CHUNK = 400      -- items per message

local function warnOnce(key, err)
  if warned[key] then return end
  warned[key] = true
  log('E', 'beamp2pVeh', key .. ': ' .. tostring(err))
end

local function refNode()
  local rn = v and v.data and v.data.refNodes and v.data.refNodes[0]
  return rn and rn.ref or 0
end

local function setRemote(on)
  isRemote = on and true or false
  if isRemote and ai and ai.setMode then pcall(ai.setMode, 'disabled') end
end

local function setOwned(on) isOwned = on and true or false end

-- ---------- driving ----------
local function inputEvent(name, value)
  if input and input.event then
    local ok, err = pcall(input.event, name, value, 2)
    if not ok then warnOnce('input.' .. name, err) end
  end
end

local function applyState(px, py, pz, vx, vy, vz, thr, brk, steer, pb, lights, horn, sigL, sigR)
  if not isRemote then return end
  target = { px, py, pz, vx, vy, vz, clock }
  inputEvent('throttle', thr)
  inputEvent('brake', brk)
  inputEvent('steering', steer)
  inputEvent('parkingbrake', pb)
  if electrics and electrics.values then
    if electrics.setLightsState then pcall(electrics.setLightsState, lights) end
    if electrics.horn then pcall(electrics.horn, horn > 0.5) end
    if electrics.toggle_left_signal then
      local ev = electrics.values
      if (sigL > 0.5) ~= ((ev.signal_left_input or 0) > 0.5) then pcall(electrics.toggle_left_signal) end
      if (sigR > 0.5) ~= ((ev.signal_right_input or 0) > 0.5) then pcall(electrics.toggle_right_signal) end
    end
  end
end

local function correct(dt)
  if not target then return end
  local age = clock - target[7]
  if age > 1.0 then return end   -- stale; wait for next packet
  local pos = obj:getPosition()
  local vel = obj:getVelocity()
  -- predict where the owner's car is now
  local tx = target[1] + target[4] * age
  local ty = target[2] + target[5] * age
  local tz = target[3] + target[6] * age
  local cx = (tx - pos.x) * CORRECT_POS + (target[4] - vel.x) * CORRECT_VEL
  local cy = (ty - pos.y) * CORRECT_POS + (target[5] - vel.y) * CORRECT_VEL
  local cz = (tz - pos.z) * CORRECT_POS + (target[6] - vel.z) * CORRECT_VEL
  local len = math.sqrt(cx * cx + cy * cy + cz * cz)
  if len > MAX_NUDGE then local s = MAX_NUDGE / len; cx, cy, cz = cx * s, cy * s, cz * s end
  local k = math.min(1, dt * 10)
  obj:applyClusterVelocityScaleAdd(refNode(), 1, cx * k, cy * k, cz * k)
end

local function report()
  local ev = electrics and electrics.values or {}
  local data = {
    i = {
      throttle = ev.throttle_input or ev.throttle or 0,
      brake = ev.brake_input or ev.brake or 0,
      steering = ev.steering_input or 0,
      parkingbrake = ev.parkingbrake_input or ev.parkingbrake or 0,
    },
    e = {
      lights = ev.lights_state or 0,
      horn = ev.horn or 0,
      signal_L = ev.signal_left_input or 0,
      signal_R = ev.signal_right_input or 0,
    },
  }
  obj:queueGameEngineLua('beamp2p.onVehInput(' .. obj:getID() .. ',' .. serialize(data) .. ')')
end

-- ---------- smooth rotation pull ----------
-- Every frame the copy is twisted a little toward the way the owner's car faces,
-- like the position pull but for rotation. All maths uses plain world vectors
-- (forward / up / spin axis), so there are no rotation-format conventions to get wrong.
local ROT_CORRECT = 4.0     -- how hard to turn toward the owner's facing (rad/s per unit of error)
local ROT_GAIN = 6.0        -- how quickly the copy's spin is adjusted (1/s)
local MAX_ROT_ACCEL = 25.0  -- cap on the twist (rad/s^2)

local facing = nil          -- owner's { d = forward, u = up, w = spin, t = time received }
local prevMy = nil          -- copy's forward/up last frame, for measuring its spin
local mySpin = { 0, 0, 0 }  -- smoothed measured spin of the copy
local cogRel = nil          -- centre of mass relative to the ref node (world-oriented)
local cogTimer = 0
local physicsFPS = nil

local function cross3(a, b)
  return { a[2] * b[3] - a[3] * b[2], a[3] * b[1] - a[1] * b[3], a[1] * b[2] - a[2] * b[1] }
end
local function dot3(a, b) return a[1] * b[1] + a[2] * b[2] + a[3] * b[3] end
local function norm3(a)
  local l = math.sqrt(dot3(a, a))
  if l < 1e-9 then return a end
  return { a[1] / l, a[2] / l, a[3] / l }
end

local function updateCog()
  local sx, sy, sz, sm = 0, 0, 0, 0
  for _, n in pairs((v and v.data and v.data.nodes) or {}) do
    if type(n) == 'table' and n.cid then
      local m = obj:getNodeMass(n.cid)
      local p = obj:getNodePosition(n.cid)
      sx, sy, sz, sm = sx + p.x * m, sy + p.y * m, sz + p.z * m, sm + m
    end
  end
  if sm > 0 then cogRel = { sx / sm, sy / sm, sz / sm } end
end

local function applyFacing(dx, dy, dz, ux, uy, uz, wx, wy, wz)
  if not isRemote then return end
  facing = { d = { dx, dy, dz }, u = { ux, uy, uz }, w = { wx, wy, wz }, t = clock }
end

local function correctRotation(dt)
  if dt <= 0 then return end
  local myD = { obj:getDirectionVectorXYZ() }
  local myU = { obj:getDirectionVectorUpXYZ() }

  -- measure how fast the copy is turning right now
  if prevMy then
    local a, b = cross3(prevMy.d, myD), cross3(prevMy.u, myU)
    local k = math.min(30 * dt, 1)
    for n = 1, 3 do mySpin[n] = mySpin[n] + ((a[n] + b[n]) / dt - mySpin[n]) * k end
  end
  prevMy = { d = myD, u = myU }

  if not facing then return end
  local age = clock - facing.t
  if age > 1.0 then return end   -- stale; wait for next packet

  cogTimer = cogTimer - dt
  if not cogRel or cogTimer <= 0 then cogTimer = 0.5; updateCog() end

  -- predict where the owner's car is facing now (it kept turning since the packet)
  local w = facing.w
  local wd, wu = cross3(w, facing.d), cross3(w, facing.u)
  local tD = norm3({ facing.d[1] + wd[1] * age, facing.d[2] + wd[2] * age, facing.d[3] + wd[3] * age })
  local tU = norm3({ facing.u[1] + wu[1] * age, facing.u[2] + wu[2] * age, facing.u[3] + wu[3] * age })

  -- facing error as a turn axis: rotating about it brings forward->forward and up->up
  local e1, e2 = cross3(myD, tD), cross3(myU, tU)
  local err = { e1[1] + e2[1], e1[2] + e2[2], e1[3] + e2[3] }
  local fd = dot3(myD, tD)
  if fd < 0 then
    -- more than 90 degrees off (e.g. spun round in a crash): keep pushing round the up axis
    local s = dot3(err, myU) >= 0 and 1 or -1
    local extra = s * (1 - fd)
    err = { err[1] + myU[1] * extra, err[2] + myU[2] * extra, err[3] + myU[3] * extra }
  end

  -- wanted spin = owner's spin + a turn toward their facing; adjust gradually and capped
  local k = math.min(ROT_GAIN * dt, 1)
  local delta = {}
  for n = 1, 3 do delta[n] = (w[n] + err[n] * ROT_CORRECT - mySpin[n]) * k end
  local len = math.sqrt(dot3(delta, delta))
  local cap = MAX_ROT_ACCEL * dt
  if len > cap then local s = cap / len; delta = { delta[1] * s, delta[2] * s, delta[3] * s } end
  if len < 1e-5 then return end

  -- spin about the centre of mass, not the ref node: cancel the sideways kick at the COG
  local c = cogRel or { 0, 0, 0 }
  local kick = cross3(delta, c)
  physicsFPS = physicsFPS or (obj.getPhysicsFPS and obj:getPhysicsFPS()) or 2000
  local f = physicsFPS
  obj:applyClusterLinearAngularAccel(refNode(),
    vec3(-kick[1] * f, -kick[2] * f, -kick[3] * f),
    vec3(delta[1] * f, delta[2] * f, delta[3] * f))
  -- the twist changes the measured spin by delta; count it so the next frame doesn't double up
  for n = 1, 3 do mySpin[n] = mySpin[n] + delta[n] end
end

-- after a snap: set the whole car's velocity to the owner's (scale 0 = replace, not add)
local function matchVelocity(vx, vy, vz)
  if not isRemote then return end
  local ok, err = pcall(function() obj:applyClusterVelocityScaleAdd(refNode(), 0, vx, vy, vz) end)
  if not ok then warnOnce('matchVelocity', err) end
  if target then target[7] = clock end
end

-- ---------- damage ----------
-- Both cars must be the same model + config, so beam ids line up. The beam count
-- travels with every damage message and mismatching cars ignore each other's damage.
local feat = nil          -- { breaks = bool, deform = bool }
local beamIds = nil       -- sorted beam ids
local baseLen = {}        -- id -> undamaged rest length
local sentBroken = {}     -- id -> true once reported
local sentLen = {}        -- id -> last reported rest length
local damageTimer = 0
local fullDamageAt = nil  -- clock time to send a full damage snapshot

local function hasMethod(name)
  local ok, f = pcall(function() return obj[name] end)
  return ok and f ~= nil
end

local function detect()
  if feat then return end
  feat = {
    breaks = hasMethod('beamIsBroken') and hasMethod('breakBeam'),
    deform = hasMethod('getBeamRestLength') and hasMethod('setBeamRestLength'),
  }
  beamIds = {}
  for _, b in pairs((v and v.data and v.data.beams) or {}) do
    if type(b) == 'table' and b.cid then beamIds[#beamIds + 1] = b.cid end
  end
  table.sort(beamIds)
  if feat.deform and not isRemote then
    for _, cid in ipairs(beamIds) do baseLen[cid] = obj:getBeamRestLength(cid) end
  end
  log('I', 'beamp2pVeh', string.format('damage sync: %d beams, breaks=%s, deform=%s',
    #beamIds, tostring(feat.breaks), tostring(feat.deform)))
end

local function sendDamage(b, d, full)
  local n = #beamIds
  local nb, nd = #b, #d
  if nb == 0 and nd == 0 and not full then return end
  local i, j = 1, 1
  repeat
    local cb, cd = {}, {}
    while i <= nb and #cb < DAMAGE_CHUNK do cb[#cb + 1] = b[i]; i = i + 1 end
    while j <= nd and #cd + #cb < DAMAGE_CHUNK do cd[#cd + 1] = d[j]; j = j + 1 end
    obj:queueGameEngineLua(string.format('beamp2p.onVehDamage(%d,%s)', obj:getID(),
      serialize({ n = n, b = cb, d = cd, full = full and true or false })))
    full = false   -- only the first chunk of a snapshot is marked full
  until i > nb and j > nd
end

local function scanDamage(full)
  detect()
  local b, d = {}, {}
  if feat.breaks then
    for _, cid in ipairs(beamIds) do
      if obj:beamIsBroken(cid) and (full or not sentBroken[cid]) then
        sentBroken[cid] = true
        b[#b + 1] = cid
      end
    end
  end
  if feat.deform then
    for _, cid in ipairs(beamIds) do
      local base = baseLen[cid]
      if base and base > 0 then
        local len = obj:getBeamRestLength(cid)
        local ref = full and base or (sentLen[cid] or base)
        if math.abs(len - ref) > base * DEFORM_THRESHOLD then
          sentLen[cid] = len
          d[#d + 1] = { cid, math.floor(len * 10000 + 0.5) / 10000 }
        end
      end
    end
  end
  sendDamage(b, d, full)
end

-- the game engine asks for this when a new player joins, so they see existing damage
local function sendFullDamage()
  fullDamageAt = clock + 2.0   -- give the newcomer time to spawn our car first
end

local function applyDamage(n, b, d)
  if not isRemote then return end
  detect()
  if n ~= #beamIds then
    warnOnce('damage', string.format('beam count differs (theirs %d, ours %d): different config, damage not applied', n, #beamIds))
    return
  end
  if feat.breaks then
    for _, cid in ipairs(b or {}) do
      if not obj:beamIsBroken(cid) then obj:breakBeam(cid) end
    end
  end
  if feat.deform then
    for _, e in ipairs(d or {}) do obj:setBeamRestLength(e[1], e[2]) end
  end
end

-- vehicle reset (repair): damage is gone, start reporting from scratch
local function onReset()
  sentBroken, sentLen = {}, {}
  prevMy, mySpin, cogRel = nil, { 0, 0, 0 }, nil
end

-- ---------- update ----------
local function updateGFX(dt)
  clock = clock + dt
  if isRemote then
    local ok, err = pcall(correct, dt)
    if not ok then warnOnce('correct', err) end
    local rok, rerr = pcall(correctRotation, dt)
    if not rok then warnOnce('rotation', rerr) end
  elseif isOwned then
    reportTimer = reportTimer - dt
    if reportTimer <= 0 then
      reportTimer = 0.05
      local ok, err = pcall(report)
      if not ok then warnOnce('report', err) end
    end
    damageTimer = damageTimer - dt
    if damageTimer <= 0 then
      damageTimer = DAMAGE_INTERVAL
      local full = fullDamageAt ~= nil and clock >= fullDamageAt
      if full then fullDamageAt = nil end
      local ok, err = pcall(scanDamage, full)
      if not ok then warnOnce('damage scan', err) end
    end
  end
end

M.matchVelocity = matchVelocity
M.setRemote = setRemote
M.setOwned = setOwned
M.applyState = applyState
M.applyFacing = applyFacing
M.applyDamage = function(n, b, d)
  local ok, err = pcall(applyDamage, n, b, d)
  if not ok then warnOnce('apply damage', err) end
end
M.sendFullDamage = sendFullDamage
M.onReset = onReset
M.updateGFX = updateGFX

return M
