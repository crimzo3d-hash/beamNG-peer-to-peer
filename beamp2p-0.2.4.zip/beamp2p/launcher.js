#!/usr/bin/env node
// BeamP2P launcher — serverless peer-to-peer multiplayer for BeamNG.drive.
// Peers find each other on the public Hyperswarm DHT (no server of yours),
// using a topic derived from room name + password. Works on Linux and Windows.
//
// Default: opens a control page in your browser (local only, token-protected).
// --cli: terminal prompts instead. Passing --room and --password also uses the terminal.
'use strict';

const Hyperswarm = require('hyperswarm');
const crypto = require('crypto');
const net = require('net');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const readline = require('readline');
const { spawn } = require('child_process');

const VERSION = 1;
const GAME_PORT_DEFAULT = 4455;
const UI_PORT_DEFAULT = 4460;
const MAX_FRAME = 256 * 1024;       // max bytes per peer message
const MAX_MSGS_PER_SEC = 120;       // per-peer flood limit
const MAX_PEERS_DEFAULT = 8;

// ---------- args ----------
function parseArgs(argv) {
  const a = {};
  for (let i = 0; i < argv.length; i++) {
    const k = argv[i];
    if (!k.startsWith('--')) continue;
    const key = k.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) a[key] = true;
    else { a[key] = next; i++; }
  }
  return a;
}
const args = parseArgs(process.argv.slice(2));

// ---------- events (terminal + GUI) ----------
const uiClients = new Set();
function emit(type, data) {
  const line = `event: ${type}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of uiClients) res.write(line);
}
function log(...m) {
  const text = m.join(' ');
  console.log(`[${new Date().toLocaleTimeString()}]`, text);
  emit('log', { time: Date.now(), text });
}

// ---------- settings ----------
function configPath() {
  const base = process.platform === 'win32'
    ? (process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'))
    : (process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config'));
  return path.join(base, 'beamp2p', 'config.json');
}
function loadConfig() {
  try { return JSON.parse(fs.readFileSync(configPath(), 'utf8')); } catch { return {}; }
}
function saveConfig(cfg) {
  try { fs.mkdirSync(path.dirname(configPath()), { recursive: true }); fs.writeFileSync(configPath(), JSON.stringify(cfg, null, 2)); }
  catch (e) { log('Could not save settings:', e.message); }
}
let config = loadConfig();

// ---------- key derivation ----------
// scrypt makes guessing the password from the public topic slow.
function deriveKeys(room, password) {
  const salt = Buffer.from('beamp2p-v1:' + room.toLowerCase());
  const out = crypto.scryptSync(password, salt, 64, { N: 1 << 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  return { topic: out.subarray(0, 32), authKey: out.subarray(32, 64) };
}

// ---------- mod install ----------
function candidateUserDirs() {
  const home = os.homedir();
  const c = [];
  if (process.platform === 'win32') {
    const la = process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local');
    c.push(path.join(la, 'BeamNG', 'BeamNG.drive'), path.join(la, 'BeamNG.drive'));
  } else {
    const xdg = process.env.XDG_DATA_HOME || path.join(home, '.local', 'share');
    c.push(path.join(xdg, 'BeamNG', 'BeamNG.drive'), path.join(xdg, 'BeamNG.drive'));
    // Proton (Steam app 284160)
    const steamRoots = [path.join(home, '.steam', 'steam'), path.join(home, '.local', 'share', 'Steam'),
      path.join(home, '.var', 'app', 'com.valvesoftware.Steam', '.local', 'share', 'Steam')];
    for (const s of steamRoots) {
      const la = path.join(s, 'steamapps', 'compatdata', '284160', 'pfx', 'drive_c', 'users', 'steamuser', 'AppData', 'Local');
      c.push(path.join(la, 'BeamNG', 'BeamNG.drive'), path.join(la, 'BeamNG.drive'));
    }
  }
  return c.filter(d => fs.existsSync(d));
}

// Returns every mods folder found: <userdir>/current/mods or <userdir>/<version>/mods
function findModsDirs() {
  const found = [];
  for (const base of candidateUserDirs()) {
    const cur = path.join(base, 'current');
    if (fs.existsSync(cur)) { found.push(path.join(cur, 'mods')); continue; }
    const versions = fs.readdirSync(base).filter(n => /^\d+\.\d+/.test(n)).sort((x, y) =>
      y.localeCompare(x, undefined, { numeric: true }));
    if (versions.length) found.push(path.join(base, versions[0], 'mods'));
  }
  return found;
}

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(s, d); else fs.copyFileSync(s, d);
  }
}

let modStatus = 'not installed';
function installMod() {
  const src = path.join(__dirname, 'mod');
  const dirs = args.mods ? [args.mods] : findModsDirs();
  let ver = '?';
  try { ver = (fs.readFileSync(path.join(src, 'lua', 'ge', 'extensions', 'beamp2p.lua'), 'utf8').match(/MOD_VERSION = '([^']+)'/) || [])[1] || '?'; } catch {}
  if (!dirs.length) {
    modStatus = 'BeamNG folder not found';
    log('Could not find your BeamNG user folder. Run the game once, or pass --mods "<path to mods folder>".');
    return;
  }
  for (const m of dirs) {
    const dst = path.join(m, 'unpacked', 'beamp2p');
    try { copyDir(src, dst); log(`Mod v${ver} installed to`, dst); modStatus = `v${ver} installed`; }
    catch (e) { log('Could not install mod to', dst, '-', e.message); }
  }
}

// ---------- framing (length-prefixed JSON) ----------
function frameWriter(sock) {
  return (obj) => {
    const body = Buffer.from(JSON.stringify(obj));
    const hdr = Buffer.alloc(4); hdr.writeUInt32BE(body.length);
    if (!sock.destroyed) sock.write(Buffer.concat([hdr, body]));
  };
}
function frameReader(sock, onMsg, onBad) {
  let buf = Buffer.alloc(0);
  sock.on('data', (d) => {
    buf = Buffer.concat([buf, d]);
    while (buf.length >= 4) {
      const n = buf.readUInt32BE(0);
      if (n > MAX_FRAME) return onBad('frame too large');
      if (buf.length < 4 + n) break;
      const body = buf.subarray(4, 4 + n); buf = buf.subarray(4 + n);
      let msg; try { msg = JSON.parse(body); } catch { return onBad('bad json'); }
      if (!msg || typeof msg !== 'object') return onBad('bad message');
      onMsg(msg);
    }
  });
}

// ---------- game bridge (localhost TCP, newline JSON) ----------
let gameSock = null;
const gameQueue = [];
function toGame(obj) {
  const line = JSON.stringify(obj) + '\n';
  if (gameSock && !gameSock.destroyed) gameSock.write(line);
  else if (obj.t !== 'state' && obj.t !== 'damage') { gameQueue.push(line); if (gameQueue.length > 500) gameQueue.shift(); }
}

// ---------- peers ----------
const peers = new Map(); // id -> { name, send, sock, authed }
let myName = 'Driver';
let myMap = null;

function cleanName(n) {
  return String(n || '').replace(/[^\w \-.]/g, '').trim().slice(0, 24) || 'Driver';
}

function broadcast(obj) {
  for (const p of peers.values()) if (p.authed) p.send(obj);
}

function peerList() {
  return [...peers.entries()].filter(([, p]) => p.authed).map(([id, p]) => ({ id, name: p.name }));
}
function emitPeers() { emit('peers', peerList()); }

// Only these message types may travel peer->game; everything else is dropped.
const ALLOWED_FROM_PEER = new Set(['spawn', 'state', 'remove', 'reset', 'map', 'chat', 'damage', 'need_sync']);
const MAX_DAMAGE_ITEMS = 6000;

function sanitizeFromPeer(msg) {
  if (!ALLOWED_FROM_PEER.has(msg.t)) return null;
  const out = { t: msg.t };
  const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);
  const arr = (v, n) => Array.isArray(v) && v.length === n ? v.map(num) : null;
  if ('vid' in msg) { if (!Number.isInteger(msg.vid)) return null; out.vid = msg.vid; }
  switch (msg.t) {
    case 'spawn':
      if (typeof msg.model !== 'string' || !/^[\w\-]{1,64}$/.test(msg.model)) return null;
      out.model = msg.model;
      out.config = typeof msg.config === 'string' ? msg.config.slice(0, 100000) : '';
      out.p = arr(msg.p, 3); out.r = arr(msg.r, 4);
      if (!out.p || !out.r) return null;
      for (const k of ['d', 'u']) if (arr(msg[k], 3)) out[k] = arr(msg[k], 3);
      break;
    case 'state':
      out.p = arr(msg.p, 3); out.r = arr(msg.r, 4); out.v = arr(msg.v, 3);
      if (!out.p || !out.r || !out.v) return null;
      for (const k of ['d', 'u']) if (arr(msg[k], 3)) out[k] = arr(msg[k], 3);
      if (arr(msg.w, 3)) out.w = arr(msg.w, 3).map(x => Math.max(-50, Math.min(50, x)));
      if (msg.i && typeof msg.i === 'object') {
        out.i = {};
        for (const k of ['throttle', 'brake', 'steering', 'parkingbrake', 'clutch'])
          out.i[k] = Math.max(-1, Math.min(1, num(msg.i[k])));
        if (Number.isInteger(msg.i.gear) && msg.i.gear >= -10 && msg.i.gear <= 20) out.i.gear = msg.i.gear;
      }
      if (msg.e && typeof msg.e === 'object') {
        out.e = {};
        for (const k of ['lights', 'horn', 'signal_L', 'signal_R', 'hazard', 'lightbar'])
          if (k in msg.e) out.e[k] = num(msg.e[k]);
      }
      break;
    case 'damage': {
      // b: broken beam ids; d: [beamId, restLength] pairs for bent beams; n: owner's beam count
      if (!Number.isInteger(msg.n) || msg.n < 0) return null;
      out.n = msg.n;
      out.full = msg.full === true;
      const b = Array.isArray(msg.b) ? msg.b.slice(0, MAX_DAMAGE_ITEMS) : [];
      out.b = b.filter(x => Number.isInteger(x) && x >= 0 && x < msg.n);
      const d = Array.isArray(msg.d) ? msg.d.slice(0, MAX_DAMAGE_ITEMS) : [];
      out.d = d.filter(x => Array.isArray(x) && x.length === 2 && Number.isInteger(x[0]) && x[0] >= 0 && x[0] < msg.n
        && typeof x[1] === 'number' && Number.isFinite(x[1]) && x[1] > 0 && x[1] < 50);
      break;
    }
    case 'map':
      if (typeof msg.map !== 'string') return null;
      out.map = msg.map.slice(0, 128);
      break;
    case 'chat':
      if (typeof msg.text !== 'string') return null;
      out.text = msg.text.slice(0, 200);
      break;
  }
  return out;
}

function handlePeer(sock, info, authKey, maxPeers) {
  const id = info.publicKey.toString('hex').slice(0, 12);
  const remoteKey = info.publicKey;
  const localKey = sock.publicKey;
  const send = frameWriter(sock);
  const peer = { name: '?', send, sock, authed: false };
  const myNonce = crypto.randomBytes(32);
  let theirNonce = null;
  let msgCount = 0;
  const rateTimer = setInterval(() => { msgCount = 0; }, 1000);

  const kill = (why) => {
    if (why) log(`Dropping peer ${id}: ${why}`);
    sock.destroy();
  };

  // Proof = HMAC(authKey, nonces + both Noise public keys). Binding the
  // encrypted channel's keys means a proof can't be replayed on another link.
  const proof = (fromKey, toKey, nA, nB) =>
    crypto.createHmac('sha256', authKey).update(Buffer.concat([fromKey, toKey, nA, nB])).digest('hex');

  // A handshake that stalls is usually a duplicate link Hyperswarm is closing
  // (both sides dialled at once). Drop it and look the room up again right away.
  const authTimeout = setTimeout(() => {
    if (peer.authed) return;
    if (theirNonce) log(`Peer ${id} did not authenticate (wrong password?) — retrying`);
    sock.destroy();
    if (disc) disc.refresh({ server: true, client: true }).catch(() => {});
  }, 5000);

  sock.on('error', () => {});
  sock.on('close', () => {
    clearInterval(rateTimer); clearTimeout(authTimeout);
    if (peers.get(id) === peer) {
      peers.delete(id);
      if (peer.authed) { log(`${peer.name} left`); toGame({ t: 'peer_leave', from: id }); emitPeers(); }
    }
  });

  send({ t: 'hello', ver: VERSION, nonce: myNonce.toString('hex') });

  frameReader(sock, (msg) => {
    if (++msgCount > MAX_MSGS_PER_SEC) return kill('flooding');
    if (!peer.authed) {
      if (msg.t === 'hello' && typeof msg.nonce === 'string' && /^[0-9a-f]{64}$/.test(msg.nonce) && !theirNonce) {
        if (msg.ver !== VERSION) return kill(`version mismatch (${msg.ver})`);
        theirNonce = Buffer.from(msg.nonce, 'hex');
        send({ t: 'auth', proof: proof(localKey, remoteKey, myNonce, theirNonce), name: myName });
      } else if (msg.t === 'auth' && theirNonce && typeof msg.proof === 'string') {
        const expect = proof(remoteKey, localKey, theirNonce, myNonce);
        const ok = msg.proof.length === expect.length &&
          crypto.timingSafeEqual(Buffer.from(msg.proof), Buffer.from(expect));
        if (!ok) return kill('wrong password');
        const dup = peers.get(id);
        const authedCount = [...peers.values()].filter(p => p.authed && p !== dup).length;
        if (authedCount >= maxPeers) return kill('room full');
        peer.authed = true; peer.name = cleanName(msg.name);
        clearTimeout(authTimeout);
        peers.set(id, peer);
        if (dup) dup.sock.destroy(); // replace duplicate link silently
        else {
          log(`${peer.name} joined (${authedCount + 1} other player(s) in room)`);
          toGame({ t: 'peer_join', from: id, name: peer.name });
          emitPeers();
        }
        toGame({ t: 'resync' }); // game re-sends our cars (and their damage) so the newcomer sees them
        if (myMap) send({ t: 'map', map: myMap });
      } else {
        kill('unexpected message before auth');
      }
      return;
    }
    const clean = sanitizeFromPeer(msg);
    if (!clean) return;
    clean.from = id;
    if (clean.t === 'chat') { log(`<${peer.name}> ${clean.text}`); emit('chat', { from: peer.name, text: clean.text }); }
    toGame(clean);
  }, (why) => kill(why));
}

// ---------- room session ----------
let swarm = null;
let disc = null;
let refreshTimer = null;
let session = null;   // { room } while in a room
let joining = false;

function swarmOptions() {
  const o = {};
  if (args.bootstrap) o.bootstrap = String(args.bootstrap).split(',').map(s => {
    const [host, port] = s.split(':'); return { host, port: Number(port) };
  });
  return o;
}

function status() {
  return {
    state: session ? 'in-room' : joining ? 'joining' : 'idle',
    room: session ? session.room : null,
    name: myName,
    game: !!(gameSock && !gameSock.destroyed),
    mod: modStatus,
    peers: peerList(),
  };
}
function emitStatus() { emit('status', status()); }

async function joinRoom(name, room, password, maxPlayers) {
  if (session || joining) throw new Error('Already in a room — leave first.');
  name = cleanName(name); room = String(room || '').trim(); password = String(password || '');
  if (!room) throw new Error('Room name is required.');
  if (!password) throw new Error('Password is required.');
  joining = true; emitStatus();
  try {
    myName = name;
    if (password.length < 6) log('Warning: short passwords are easy to guess. 10+ characters recommended.');
    log('Deriving room keys…');
    await new Promise(r => setImmediate(r));
    const { topic, authKey } = deriveKeys(room, password);
    const maxPeers = Number(maxPlayers) > 1 ? Math.min(32, Number(maxPlayers)) - 1 : MAX_PEERS_DEFAULT - 1;
    swarm = new Hyperswarm(swarmOptions());
    swarm.on('connection', (sock, info) => handlePeer(sock, info, authKey, maxPeers));
    disc = swarm.join(topic, { server: true, client: true });
    log('Joining room on the P2P network…');
    await disc.flushed();
    // re-announce and re-look-up regularly so players who joined at the same moment still find each other
    refreshTimer = setInterval(() => { if (disc) disc.refresh({ server: true, client: true }).catch(() => {}); }, 15000);
    session = { room };
    // remember name + room (never the password)
    const recent = [room, ...(config.recentRooms || []).filter(r => r.toLowerCase() !== room.toLowerCase())].slice(0, 6);
    config = { ...config, name, room, recentRooms: recent };
    saveConfig(config);
    log(`In room "${room}". Start BeamNG.drive and load a map. Friends join with the same room + password.`);
  } catch (e) {
    if (swarm) await swarm.destroy().catch(() => {});
    swarm = null; disc = null;
    throw e;
  } finally {
    joining = false; emitStatus();
  }
}

async function leaveRoom() {
  if (!session) return;
  log(`Leaving room "${session.room}"…`);
  clearInterval(refreshTimer); refreshTimer = null;
  for (const [id, p] of peers) { if (p.authed) toGame({ t: 'peer_leave', from: id }); p.sock.destroy(); }
  peers.clear();
  if (swarm) await swarm.destroy().catch(() => {});
  swarm = null; disc = null; session = null;
  emitPeers(); emitStatus();
  log('Left the room.');
}

function sendChat(text) {
  text = String(text || '').trim().slice(0, 200);
  if (!text) return;
  if (text === '/reset') return resetOthers();
  broadcast({ t: 'chat', text });
  toGame({ t: 'chat', from: 'me', text });
  emit('chat', { from: myName, text, me: true });
}

function resetOthers() {
  toGame({ t: 'reset_remote' });
  log('Resetting other players\' cars');
}

// ---------- game socket server ----------
function startGameBridge(port) {
  const server = net.createServer((sock) => {
    if (gameSock && !gameSock.destroyed) gameSock.destroy();
    gameSock = sock;
    sock.setNoDelay(true);
    log('BeamNG connected to launcher');
    emitStatus();
    // peer_join is re-sent from the live peer list below, so skip queued copies
    for (const line of gameQueue.splice(0)) if (!line.includes('"t":"peer_join"')) sock.write(line);
    for (const [id, p] of peers) if (p.authed) sock.write(JSON.stringify({ t: 'peer_join', from: id, name: p.name }) + '\n');
    sock.write(JSON.stringify({ t: 'welcome', name: myName, players: peerList().length }) + '\n');
    let buf = '';
    sock.on('data', (d) => {
      buf += d.toString();
      if (buf.length > 8 * MAX_FRAME) { buf = ''; return; }
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1);
        if (!line.trim()) continue;
        let msg; try { msg = JSON.parse(line); } catch { continue; }
        if (msg.t === 'map') myMap = msg.map;
        if (ALLOWED_FROM_PEER.has(msg.t)) broadcast(msg);
      }
    });
    sock.on('error', () => {});
    sock.on('close', () => { if (gameSock === sock) { gameSock = null; log('BeamNG disconnected'); emitStatus(); } });
  });
  server.on('error', (e) => { log('Game bridge error:', e.message, '(is another launcher already running?)'); process.exit(1); });
  server.listen(port, '127.0.0.1', () => log(`Waiting for BeamNG on 127.0.0.1:${port}`));
}

// ---------- GUI server (localhost only, token-protected) ----------
function openBrowser(url) {
  const cmd = process.platform === 'win32' ? ['cmd', ['/c', 'start', '""', url]]
    : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  try {
    const p = spawn(cmd[0], cmd[1], { detached: true, stdio: 'ignore', windowsVerbatimArguments: process.platform === 'win32' });
    p.on('error', () => log(`Open this in your browser: ${url}`));
    p.unref();
  } catch { log(`Open this in your browser: ${url}`); }
}

function startUI(preferredPort, onQuit) {
  const token = crypto.randomBytes(16).toString('hex');
  const html = fs.readFileSync(path.join(__dirname, 'ui.html'), 'utf8');
  let port = preferredPort;

  const readBody = (req) => new Promise((res, rej) => {
    let b = '';
    req.on('data', (c) => { b += c; if (b.length > 10000) { rej(new Error('too large')); req.destroy(); } });
    req.on('end', () => { try { res(b ? JSON.parse(b) : {}); } catch { rej(new Error('bad json')); } });
  });
  const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };

  const server = http.createServer(async (req, res) => {
    // block DNS-rebinding and other sites: only our own host, and every call needs the token
    const host = req.headers.host || '';
    if (host !== `127.0.0.1:${port}` && host !== `localhost:${port}`) { res.writeHead(403); return res.end(); }
    const url = new URL(req.url, `http://${host}`);
    const tok = url.searchParams.get('t') || req.headers['x-token'];
    if (tok !== token) { res.writeHead(403, { 'Content-Type': 'text/plain' }); return res.end('Open the link the launcher printed.'); }

    if (req.method === 'GET' && url.pathname === '/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store',
        'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'" });
      return res.end(html);
    }
    if (req.method === 'GET' && url.pathname === '/events') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
      res.write(`event: status\ndata: ${JSON.stringify(status())}\n\n`);
      res.write(`event: config\ndata: ${JSON.stringify({ name: config.name || '', room: config.room || '', recentRooms: config.recentRooms || [] })}\n\n`);
      uiClients.add(res);
      const ping = setInterval(() => res.write(': ping\n\n'), 20000);
      req.on('close', () => { clearInterval(ping); uiClients.delete(res); });
      return;
    }
    if (req.method !== 'POST') { res.writeHead(404); return res.end(); }
    let body;
    try { body = await readBody(req); } catch (e) { return json(res, 400, { error: e.message }); }
    try {
      switch (url.pathname) {
        case '/api/join': await joinRoom(body.name, body.room, body.password, body.maxPlayers); return json(res, 200, { ok: true });
        case '/api/leave': await leaveRoom(); return json(res, 200, { ok: true });
        case '/api/chat': sendChat(body.text); return json(res, 200, { ok: true });
        case '/api/reset': resetOthers(); return json(res, 200, { ok: true });
        case '/api/reinstall': installMod(); emitStatus(); return json(res, 200, { ok: true });
        case '/api/quit': json(res, 200, { ok: true }); return setTimeout(onQuit, 100);
        default: res.writeHead(404); return res.end();
      }
    } catch (e) {
      log('Error:', e.message);
      return json(res, 400, { error: e.message });
    }
  });

  const listen = (p) => server.listen(p, '127.0.0.1');
  server.on('listening', () => {
    port = server.address().port;
    const url = `http://127.0.0.1:${port}/?t=${token}`;
    log(`Launcher window: ${url}`);
    if (!args['no-browser']) openBrowser(url);
  });
  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE' && port !== 0) { port = 0; listen(0); }
    else log('UI server error:', e.message);
  });
  listen(port);
}

// ---------- terminal prompts ----------
function ask(rl, q, hidden = false) {
  return new Promise((res) => {
    if (!hidden) return rl.question(q, res);
    const out = process.stdout;
    const orig = rl._writeToOutput;
    rl._writeToOutput = (s) => { if (s.startsWith(q)) out.write(s); else out.write('*'); };
    rl.question(q, (a) => { rl._writeToOutput = orig; out.write('\n'); res(a); });
  });
}

async function main() {
  console.log(`\n  BeamP2P — peer-to-peer BeamNG multiplayer (no server)\n`);
  if (args['install-only']) { installMod(); return; }
  if (!args['no-install']) installMod();
  myName = cleanName(args.name || config.name || 'Driver');

  startGameBridge(Number(args.port) || GAME_PORT_DEFAULT);

  const shutdown = async () => { await leaveRoom().catch(() => {}); process.exit(0); };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  const cli = args.cli || (args.room && args.password);
  if (!cli) {
    startUI(Number(args['ui-port']) || UI_PORT_DEFAULT, shutdown);
    log('Use the launcher window in your browser. Ctrl+C here to quit.');
    return;
  }

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const name = args.name || await ask(rl, `Your name${config.name ? ` [${config.name}]` : ''}: `) || config.name;
  const room = String(args.room || await ask(rl, `Room name${config.room ? ` [${config.room}]` : ''}: `) || config.room || '').trim();
  const password = String(args.password || await ask(rl, 'Room password: ', true));
  try { await joinRoom(name, room, password, args['max-players']); }
  catch (e) { log(e.message); process.exit(1); }
  log('Type a message and press Enter to chat. /reset = reset other players\' cars. Ctrl+C to quit.');
  rl.on('line', (line) => sendChat(line));
  rl.on('close', shutdown);
}

main().catch((e) => { console.error(e); process.exit(1); });
