#!/usr/bin/env node
// BeamP2P test bot — a fake second player for testing on your own.
// It joins your room like a real peer and sends back a "ghost" copy of
// every car you drive, replayed DELAY seconds later and offset sideways.
//
//   node bot.js --room myroom --password mypassword [--delay 2] [--offset 5]
'use strict';

const Hyperswarm = require('hyperswarm');
const crypto = require('crypto');

const VERSION = 1;
const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const k = process.argv[i];
  if (!k.startsWith('--')) continue;
  const n = process.argv[i + 1];
  if (n === undefined || n.startsWith('--')) args[k.slice(2)] = true; else { args[k.slice(2)] = n; i++; }
}
if (!args.room || !args.password) {
  console.log('Usage: node bot.js --room <room> --password <password> [--delay 2] [--offset 5]');
  process.exit(1);
}
const DELAY = (Number(args.delay) || 2) * 1000;
const OFFSET = args.offset !== undefined ? Number(args.offset) : 5;
const log = (...m) => console.log(`[bot ${new Date().toLocaleTimeString()}]`, ...m);

// must match launcher.js
const salt = Buffer.from('beamp2p-v1:' + String(args.room).trim().toLowerCase());
const keys = crypto.scryptSync(String(args.password), salt, 64, { N: 1 << 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
const topic = keys.subarray(0, 32), authKey = keys.subarray(32, 64);

const shift = (p) => [p[0] + OFFSET, p[1], p[2]];

function handle(sock, info) {
  const id = info.publicKey.toString('hex').slice(0, 12);
  const remoteKey = info.publicKey, localKey = sock.publicKey;
  const myNonce = crypto.randomBytes(32);
  let theirNonce = null, authed = false, stats = { state: 0 };
  const timers = new Set();
  const send = (o) => {
    if (sock.destroyed) return;
    const b = Buffer.from(JSON.stringify(o)), h = Buffer.alloc(4); h.writeUInt32BE(b.length);
    sock.write(Buffer.concat([h, b]));
  };
  const later = (fn) => { const t = setTimeout(() => { timers.delete(t); fn(); }, DELAY); timers.add(t); };
  const proof = (a, b, nA, nB) => crypto.createHmac('sha256', authKey).update(Buffer.concat([a, b, nA, nB])).digest('hex');

  sock.on('error', () => {});
  sock.on('close', () => { timers.forEach(clearTimeout); clearTimeout(authTimer); if (authed) log(`player ${id} disconnected`); });
  // stalled handshake (duplicate link being closed): drop it and look again
  const authTimer = setTimeout(() => {
    if (!authed) { sock.destroy(); if (globalThis.botDisc) globalThis.botDisc.refresh({ server: true, client: true }).catch(() => {}); }
  }, 5000);
  send({ t: 'hello', ver: VERSION, nonce: myNonce.toString('hex') });

  const report = setInterval(() => {
    if (authed && stats.state) { log(`receiving ${stats.state} car updates/sec, ghosting them back`); }
    stats.state = 0;
  }, 5000);
  sock.on('close', () => clearInterval(report));

  let buf = Buffer.alloc(0);
  sock.on('data', (d) => {
    buf = Buffer.concat([buf, d]);
    while (buf.length >= 4) {
      const n = buf.readUInt32BE(0);
      if (buf.length < 4 + n) break;
      let m; try { m = JSON.parse(buf.subarray(4, 4 + n)); } catch { m = null; }
      buf = buf.subarray(4 + n);
      if (!m) continue;
      if (!authed) {
        if (m.t === 'hello') {
          theirNonce = Buffer.from(m.nonce, 'hex');
          send({ t: 'auth', proof: proof(localKey, remoteKey, myNonce, theirNonce), name: 'TestBot' });
        } else if (m.t === 'auth' && theirNonce) {
          if (m.proof !== proof(remoteKey, localKey, theirNonce, myNonce)) { log('password mismatch'); sock.destroy(); return; }
          authed = true;
          log(`connected to player ${m.name} (${id}). Spawn a car in BeamNG — a ghost copy appears ${DELAY / 1000}s later, ${OFFSET} m to the side.`);
          send({ t: 'chat', text: 'TestBot here: I will copy your driving' });
        }
        continue;
      }
      switch (m.t) {
        case 'spawn': log(`you spawned ${m.model}; ghosting it`); later(() => send({ ...m, p: shift(m.p) })); break;
        case 'state': stats.state++; later(() => send({ ...m, p: shift(m.p) })); break;
        case 'remove': case 'reset': case 'damage': later(() => send(m)); break;
        case 'map': log(`you're on map ${m.map}`); send({ t: 'map', map: m.map }); break;
        case 'chat': log(`chat: ${m.text}`); send({ t: 'chat', text: `you said: ${m.text}` }); break;
      }
    }
  });
}

(async () => {
  const opts = {};
  if (args.bootstrap) opts.bootstrap = String(args.bootstrap).split(',').map(s => { const [host, port] = s.split(':'); return { host, port: Number(port) }; });
  const swarm = new Hyperswarm(opts);
  swarm.on('connection', handle);
  const disc = swarm.join(topic, { server: true, client: true });
  globalThis.botDisc = disc;
  await disc.flushed();
  setInterval(() => disc.refresh({ server: true, client: true }).catch(() => {}), 15000).unref();
  log(`waiting in room "${args.room}" for the launcher to connect…`);
  process.on('SIGINT', async () => { await swarm.destroy().catch(() => {}); process.exit(0); });
})();
